import sys
import os
import asyncio
import signal
import yaml
import json
from pathlib import Path
from datetime import datetime
from typing import Dict, Any

project_root = Path(__file__).parent
src_dir = project_root / "src"
sys.path.insert(0, str(project_root))
sys.path.insert(0, str(src_dir))

print("=" * 60)
print("🤖 Agentic VSC System - 视频语义通信系统")
print("=" * 60)

try:
    from src.communication.message_bus import MessageBus
    from src.agents.cloud_agent import CloudAgent
    from src.agents.edge_agent import EdgeAgent
    from src.agents.embodied_agent import EmbodiedAgent
    print("✅ 所有模块导入成功")
except ImportError as e:
    print(f"❌ 模块导入失败: {e}")
    print("请确保目录结构正确")
    sys.exit(1)

class TaskManager:
    def __init__(self, cloud_agent):
        self.cloud_agent = cloud_agent
        self.task_history = []
        
    async def run_interactive(self):
        print("\n" + "=" * 60)
        print("📝 交互式任务模式")
        print("=" * 60)
        
        while True:
            print("\n请选择操作:")
            print("1. 📝 输入新任务")
            print("4. 🚪 退出系统")
            
            try:
                choice = input("\n请输入选项 (1/4): ").strip()
                
                if choice == "1":
                    await self._input_new_task()
                elif choice == "4":
                    print("👋 退出系统...")
                    return True
                else:
                    print("❌ 无效选项，请重新选择")
                    

            except KeyboardInterrupt:
                print("\n\n⚠️  用户中断")
                break
            except Exception as e:
                print(f"❌ 发生错误: {e}")
                
        return False
    
    async def _input_new_task(self):
        print("\n" + "=" * 50)
        print("📝 请输入您的任务描述")
        print("=" * 50)
        
        print("\n💡 任务示例:")
        print(" 从路边摄像头视频中提取车辆信息")


        
        try:
            task_description = input("\n请输入任务描述: ").strip()
            
            if not task_description:
                print("⚠️  任务描述不能为空")
                return
                
            if len(task_description) < 5:
                print("⚠️  任务描述太简短，请更详细地描述")
                return
                
            print(f"\n✅ 已接收任务: '{task_description}'")
            
            task_record = await self.cloud_agent.deploy_task(task_description)
            
            if task_record:
                self.task_history.append(task_record)
                print(f"✅ 任务已部署，ID: {task_record['task_id']}")
                
                print("\n⏳ 任务执行中...")
                await asyncio.sleep(3)
                print("✅ 任务执行完成，请查看系统日志和报告")
            else:
                print("❌ 任务部署失败")
                
        except KeyboardInterrupt:
            print("\n\n⚠️  取消任务输入")
        except Exception as e:
            print(f"❌ 任务输入错误: {e}")

class AgenticSystem:
    def __init__(self, config_path="config/system_config.yaml"):
        self.message_bus = MessageBus()
        self.agents = {}
        self.is_running = False
        self.task_manager = None
        self.config = self._load_config(config_path)
        
    def _load_config(self, config_path):
        config_file = Path(config_path)
        if config_file.exists():
            with open(config_file, 'r', encoding='utf-8') as f:
                return yaml.safe_load(f)
        else:
            print(f"⚠️  配置文件不存在: {config_path}")
            return {}
    
    async def setup(self):
        print("\n🚀 初始化智能体...")
        
        self.agents['cloud'] = CloudAgent("cloud_agent", self.message_bus)
        print("   ☁️  Cloud Agent: 创建成功")
        
        self.agents['edge'] = EdgeAgent("edge_agent", self.message_bus)
        print("   🔧  Edge Agent: 创建成功")
        
        self.agents['embodied'] = EmbodiedAgent("embodied_agent", self.message_bus, data_source="kitti")
        print("   📷  Embodied Agent: 创建成功")
        
        self.task_manager = TaskManager(self.agents['cloud'])
        
        print("\n🚀 启动智能体...")
        for name, agent in self.agents.items():
            await agent.start()
            await asyncio.sleep(0.1)
        
        self.is_running = True
        print("\n✅ 系统启动完成")
        
        print("\n" + "=" * 60)
 
        if hasattr(self.agents['cloud'], 'openai_client') and self.agents['cloud'].openai_client:
            print("✓ OpenAI集成: 已启用")
        else:
            print("⚠️ OpenAI集成: 未启用 (请检查配置)")
    
    async def run(self):
        try:
            should_exit = await self.task_manager.run_interactive()
            
            if should_exit:
                return True
                
        except KeyboardInterrupt:
            print("\n\n⚠️  用户中断")
            return True
        except Exception as e:
            print(f"\n❌ 系统运行错误: {e}")
            import traceback
            traceback.print_exc()
            return True
            
        return False
    
    async def shutdown(self):
        print("\n🛑 正在关闭系统...")
        
        self.is_running = False
        
        for name, agent in self.agents.items():
            try:
                await agent.stop()
                print(f"   🛑 {name}_agent 已停止")
            except Exception as e:
                print(f"   ⚠️  {name}_agent 停止失败: {e}")
        
        self._save_task_history()
        
        print("\n✅ 系统已关闭")
        print("=" * 60)
    
    def _save_task_history(self):
        if not self.task_manager or not self.task_manager.task_history:
            return
            
        logs_dir = Path("logs")
        logs_dir.mkdir(exist_ok=True)
        
        history_file = logs_dir / "task_history.json"
        
        history_data = {
            "system": "Agentic_VSC_System",
            "total_tasks": len(self.task_manager.task_history),
            "tasks": self.task_manager.task_history,
            "saved_at": datetime.now().isoformat()
        }
        
        try:
            with open(history_file, 'w', encoding='utf-8') as f:
                json.dump(history_data, f, indent=2, ensure_ascii=False)
            print(f"📝 任务历史已保存到: {history_file}")
        except Exception as e:
            print(f"⚠️  保存任务历史失败: {e}")

async def main():
    system = AgenticSystem()
    
    def signal_handler(signum, frame):
        print(f"\n📶 收到信号 {signum}，正在优雅关闭...")
        asyncio.create_task(system.shutdown())
    
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    try:
        await system.setup()
        
        while system.is_running:
            should_exit = await system.run()
            if should_exit:
                break
        
    except KeyboardInterrupt:
        print("\n👋 用户中断")
    except Exception as e:
        print(f"\n❌ 系统错误: {e}")
        import traceback
        traceback.print_exc()
    finally:
        if system.is_running:
            await system.shutdown()

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n👋 程序结束")
        sys.exit(0)