import sys
import os
import asyncio
import signal
import yaml
import json
from pathlib import Path
from datetime import datetime
from typing import Dict, Any

project_root = Path(__file__).parent
src_dir = project_root / "src"
sys.path.insert(0, str(project_root))
sys.path.insert(0, str(src_dir))

print("=" * 60)
print("🤖 Agentic VSC System - Video Semantic Communication System")
print("=" * 60)

try:
    from src.communication.message_bus import MessageBus
    from src.agents.cloud_agent import CloudAgent
    from src.agents.edge_agent import EdgeAgent
    from src.agents.embodied_agent import EmbodiedAgent
    print("✅ All modules imported successfully")
except ImportError as e:
    print(f"❌ Module import failed: {e}")
    print("Please ensure directory structure is correct")
    sys.exit(1)

# Windows compatibility settings
if sys.platform == 'win32':
    try:
        asyncio.set_event_loop_policy(asyncio.WindowsProactorEventLoopPolicy())
    except Exception as e:
        print(f"⚠️  Windows compatibility settings failed: {e}")


class GracefulShutdown:
    """Cross-platform graceful shutdown manager"""
    
    def __init__(self):
        self.should_exit = False
        self.signal_received = None
        
    def setup_signal_handlers(self):
        """Set up cross-platform signal handlers"""
        try:
            if sys.platform == 'win32':
        
                signal.signal(signal.SIGINT, self._signal_handler_windows)
            else:
                # Unix/Linux: Can handle SIGINT and SIGTERM
                signal.signal(signal.SIGINT, self._signal_handler_unix)
                signal.signal(signal.SIGTERM, self._signal_handler_unix)
                print("✅ Unix signal handler set up (SIGINT, SIGTERM)")
        except Exception as e:
            print(f"⚠️  Signal handler setup failed: {e}")
            print("💡 On Windows, use Ctrl+C to interrupt the program")
    
    def _signal_handler_windows(self, signum, frame):
        """Windows signal handler"""
        self.signal_received = signum
        self.should_exit = True
        print(f"\n📶 Windows: Received signal {signum} (Ctrl+C)")
    
    def _signal_handler_unix(self, signum, frame):
        """Unix signal handler"""
        self.signal_received = signum
        self.should_exit = True
        signal_name = "SIGINT" if signum == signal.SIGINT else "SIGTERM"
        print(f"\n📶 Unix: Received signal {signal_name}")


class EnglishTaskManager:
    def __init__(self, cloud_agent):
        self.cloud_agent = cloud_agent
        self.task_history = []
        
    async def run_interactive(self):
        print("\n" + "=" * 60)
        print("📝 Interactive Task Mode")
        print("=" * 60)
        
        while True:
            print("\nPlease select an option:")
            print("1. 📝 Enter a new task")
            print("4. 🚪 Exit system")
            
            try:
                choice = input("\nEnter your choice (1/4): ").strip()
                
                if choice == "1":
                    await self._input_new_task()
                elif choice == "4":
                    print("👋 Exiting system...")
                    return True
                else:
                    print("❌ Invalid option, please choose again")
                    
            except KeyboardInterrupt:
                print("\n\n⚠️ User interrupted")
                break
            except Exception as e:
                print(f"❌ Error occurred: {e}")
                    
        return False
    
    async def _input_new_task(self):
        print("\n" + "=" * 50)
        print("📝 Enter Your Task Description")
        print("=" * 50)
        
        print("\n💡 Task example:")
        print("  I want to extract vehicles from road videos captured by roadside cameras.")
        
        try:
            task_description = input("\nEnter task description: ").strip()
            
            if not task_description:
                print("⚠️ Task description cannot be empty")
                return
                
            if len(task_description) < 5:
                print("⚠️ Task description too short, please describe in more detail")
                return
                
            print(f"\n✅ Task received: '{task_description}'")
            
            task_record = await self.cloud_agent.deploy_task(task_description)
            
            if task_record:
                self.task_history.append(task_record)
                print(f"✅ Task deployed, ID: {task_record['task_id']}")
                
                print("\n⏳ Task executing...")
                await asyncio.sleep(2)
                print("✅ Task execution completed. Check system logs and reports.")
            else:
                print("❌ Task deployment failed")
                
        except KeyboardInterrupt:
            print("\n\n⚠️ Task input cancelled")
            return
        except EOFError:
            print("\n\n📖 End of input")
            return
        except Exception as e:
            print(f"❌ Task input error: {e}")
    
    async def _view_system_status(self):
        """View system status"""
        print("\n" + "=" * 50)
        print("📊 System Status")
        print("=" * 50)
        
        if hasattr(self.cloud_agent, 'get_system_status'):
            status = self.cloud_agent.get_system_status()
            print(f"Cloud Agent: {status.get('status', 'Unknown')}")
            print(f"Current Model: {status.get('model_state', 'Unknown')}")
            print(f"Tasks Deployed: {status.get('task_count', 0)}")
            print(f"OpenAI Enabled: {status.get('openai_enabled', False)}")
        
        print(f"\nTask History: {len(self.task_history)} tasks")
        for i, task in enumerate(self.task_history[-5:]):  # Show last 5 tasks
            print(f"  {i+1}. {task.get('task_id', 'Unknown')}: {task.get('description', '')[:50]}...")
    
    def _view_task_history(self):
        """View task history"""
        if not self.task_history:
            print("\n📭 No task history available")
            return
        
        print("\n" + "=" * 50)
        print("📁 Task History")
        print("=" * 50)
        
        for i, task in enumerate(self.task_history):
            print(f"\nTask {i+1}:")
            print(f"  ID: {task.get('task_id', 'Unknown')}")
            print(f"  Description: {task.get('description', '')[:100]}")
            print(f"  Deployed at: {task.get('deployed_at', 'Unknown')}")
            print(f"  Status: {task.get('status', 'Unknown')}")


class AgenticSystem:
    def __init__(self, config_path="config/system_config.yaml"):
        self.message_bus = MessageBus()
        self.agents = {}
        self.is_running = False
        self.task_manager = None
        self.config = self._load_config(config_path)
        
        self.task_history = []

    def _load_config(self, config_path):
        config_file = Path(config_path)
        if config_file.exists():
            try:
                with open(config_file, 'r', encoding='utf-8') as f:
                    return yaml.safe_load(f)
            except Exception as e:
                print(f"⚠️ Config file read failed: {e}")
                return {}
        else:
            print(f"⚠️ Config file not found: {config_path}")
            return {}
    
    def _create_default_config(self, config_file):
        """Create default configuration file"""
        try:
            import yaml
            default_config = {
                'system': {
                    'name': 'Agentic_VSC_System',
                    'version': '5.0'
                },
                'openai': {
                    'enabled': False,
                    'api_key': '',
                    'model': 'gpt-4'
                },
                'thresholds': {
                    'mAP': 0.35,
                    'snr_fluctuation': 3.0
                },
                'ewc': {
                    'enabled': True,
                    'importance': 1000.0,
                    'fisher_samples': 30,
                    'training_epochs': 5
                }
            }
            
            config_file.parent.mkdir(parents=True, exist_ok=True)
            with open(config_file, 'w', encoding='utf-8') as f:
                yaml.dump(default_config, f, default_flow_style=False)
            print(f"✅ Created default configuration file: {config_file}")
        except Exception as e:
            print(f"❌ Failed to create default configuration: {e}")
    
    async def setup(self):
        print("\n🚀 Initializing agents...")
        
        # Check configuration file
        config_file = Path("config/system_config.yaml")
        if not config_file.exists():
            print("⚠️ Configuration file not found, creating default configuration...")
            self._create_default_config(config_file)
        
        # Check model files
        model_a = Path("models/yolov8n.pt")
        if not model_a.exists():
            print("⚠️ Model A (yolov8n.pt) not found")
            print("   System will attempt to download automatically at runtime")
        
        model_b = Path("models/model_b_kitti_ewc.pt")
        if not model_b.exists():
            print("⚠️ Model B (model_b_kitti_ewc.pt) not found")
            print("   System will generate as needed")
        
        # Check data directory
        kitti_dir = Path("data/kitti")
        if not kitti_dir.exists():
            print("⚠️ KITTI data directory not found, will use simulated data")
            kitti_dir.mkdir(parents=True, exist_ok=True)
        
        # Create necessary directories
        for dir_path in ["logs", "reports", "models", "data", "workflow_steps", 
                        "workflow_steps/prompts", "workflow_steps/json_commands", "workflow_steps/reports"]:
            Path(dir_path).mkdir(parents=True, exist_ok=True)
        
        # Create agents
        try:
            self.agents['cloud'] = CloudAgent("cloud_agent", self.message_bus)
            print("   ☁️  Cloud Agent: Created successfully")
            
            self.agents['edge'] = EdgeAgent("edge_agent", self.message_bus)
            print("   🔧  Edge Agent: Created successfully")
            
            self.agents['embodied'] = EmbodiedAgent("embodied_agent", self.message_bus, data_source="kitti")
            print("   📷  Embodied Agent: Created successfully")
        except Exception as e:
            print(f"❌ Agent creation failed: {e}")
            return False
        
        self.task_manager = EnglishTaskManager(self.agents['cloud'])
        
        print("\n🚀 Starting agents...")
        try:
            for name, agent in self.agents.items():
                await agent.start()
                await asyncio.sleep(0.2)  # Ensure sequential startup
        except Exception as e:
            print(f"❌ Agent startup failed: {e}")
            return False
        
        self.is_running = True
        print("\n✅ System startup completed")
        
        print("\n" + "=" * 60)
        print("📋 System Information:")
        print(f"   Model A (COCO): models/yolov8n.pt")
        print(f"   Model B (KITTI): models/model_b_kitti_ewc.pt")
        print(f"   Dataset: KITTI")
        print(f"   Thresholds: mAP<{self.config.get('thresholds', {}).get('mAP', 0.35)}, SNR fluctuation≥{self.config.get('thresholds', {}).get('snr_fluctuation', 3.0)}dB")
        print("=" * 60)
        
        return True
    
    async def run(self):
        try:
            should_exit = await self.task_manager.run_interactive()
            
            if should_exit:
                return True
                
        except KeyboardInterrupt:
            print("\n\n⚠️ User interrupted")
            return True
        except EOFError:
            print("\n\n📖 End of input")
            return True
        except Exception as e:
            print(f"\n❌ System running error: {e}")
            import traceback
            traceback.print_exc()
            return True
            
        return False
    
    async def shutdown(self):
        """Shut down the system - ensure only executed once"""
        if not self.is_running:
            print("⚠️ System already shutting down or already shut down")
            return
        
        print("\n🛑 Shutting down system...")
        self.is_running = False  # Immediately set flag to prevent repeated calls
        
        # Stop all agents
        for name, agent in self.agents.items():
            try:
                if hasattr(agent, 'is_running') and agent.is_running:
                    await agent.stop()
                    print(f"   🛑 {name}_agent stopped")
                else:
                    print(f"   ℹ️  {name}_agent not running or already stopped")
            except Exception as e:
                print(f"   ⚠️  {name}_agent stop failed: {e}")
        
        # Save task history
        self._save_task_history()
        
        print("\n✅ System shut down")
        print("=" * 60)
    
    def _save_task_history(self):
        """Save task history"""
        if not self.task_history:
            print("ℹ️ No task history to save")
            return
            
        logs_dir = Path("logs")
        logs_dir.mkdir(exist_ok=True)
        
        history_file = logs_dir / "task_history.json"
        
        history_data = {
            "system": "Agentic_VSC_System",
            "total_tasks": len(self.task_history),
            "tasks": self.task_history,
            "saved_at": datetime.now().isoformat()
        }
        
        try:
            with open(history_file, 'w', encoding='utf-8') as f:
                json.dump(history_data, f, indent=2, ensure_ascii=False)
            print(f"📝 Task history saved to: {history_file}")
        except Exception as e:
            print(f"⚠️ Failed to save task history: {e}")


async def main():
    system = AgenticSystem()
    
    # Create cross-platform shutdown manager
    shutdown_manager = GracefulShutdown()
    shutdown_manager.setup_signal_handlers()
    
    try:
        # Set up system
        setup_success = await system.setup()
        if not setup_success:
            print("❌ System setup failed")
            return
        
        # Main running loop
        while system.is_running and not shutdown_manager.should_exit:
            should_exit = await system.run()
            if should_exit:
                break

            # Brief sleep to avoid high CPU usage
            await asyncio.sleep(0.1)

    except KeyboardInterrupt:
        print("\n👋 User interrupt (KeyboardInterrupt)")
    except EOFError:
        print("\n📖 End of input (EOF)")
    except Exception as e:
        print(f"\n❌ System error: {e}")
        import traceback
        traceback.print_exc()
    finally:
        # Ensure system is shut down
        if system.is_running:
            await system.shutdown()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n👋 Program terminated (Ctrl+C)")
        sys.exit(0)
    except Exception as e:
        print(f"\n❌ Program startup failed: {e}")
        sys.exit(1)
