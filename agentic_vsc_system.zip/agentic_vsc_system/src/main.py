import sys
import os

# 设置Python路径
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
src_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, project_root)
sys.path.insert(0, src_dir)


from communication.message_bus import MessageBus
from agents.cloud_agent import CloudAgent
from agents.edge_agent import EdgeAgent
from agents.embodied_agent import EmbodiedAgent

import asyncio
import signal

class AgenticSystem:
    def __init__(self):
        self.message_bus = MessageBus()
        self.agents = {}
        self.is_running = False
        
    async def setup(self):
        print("=" * 60)
        print("🤖 启动多智能体视频语义通信系统")
        print("=" * 60)
        
        # 创建所有智能体
        self.agents['cloud'] = CloudAgent("cloud_agent", self.message_bus)
        self.agents['edge'] = EdgeAgent("edge_agent", self.message_bus)
        self.agents['embodied'] = EmbodiedAgent("embodied_agent", self.message_bus, data_source="kitti")
        
        print("\n🚀 启动智能体...")
        for name, agent in self.agents.items():
             await agent.start()
    
        self.is_running = True
        
    async def run(self):
        print("\n🚀 系统运行中...")
        print("按 Ctrl+C 停止\n")
        
        await asyncio.sleep(1)
        
        task = "I want to extract vehicles from road videos captured by roadside cameras."
        await self.agents['cloud'].deploy_task(task)
        
        try:
            while self.is_running:
                await asyncio.sleep(1)
        except asyncio.CancelledError:
            pass
            
    async def shutdown(self):
        print("\n🛑 正在关闭系统...")
        
        for name, agent in self.agents.items():
            await agent.stop()
            print(f"🛑 {name}_agent 停止")
            
        self.is_running = False
        print("✅ 系统已关闭")

async def main():
    system = AgenticSystem()
    
    def signal_handler(signum, frame):
        print(f"\n收到信号 {signum}，正在关闭...")
        asyncio.create_task(system.shutdown())
    
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    try:
        await system.setup()
        await system.run()
    finally:
        await system.shutdown()

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n👋 用户中断")
        sys.exit(0)