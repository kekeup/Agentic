import sys
import os

# Set Python path
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
src_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, project_root)
sys.path.insert(0, src_dir)


from communication.message_bus import MessageBus
from agents.cloud_agent import CloudAgent
from agents.edge_agent import EdgeAgent
from agents.embodied_agent import EmbodiedAgent

import asyncio
import signal

class AgenticSystem:
    def __init__(self):
        self.message_bus = MessageBus()
        self.agents = {}
        self.is_running = False
        
    async def setup(self):
        print("=" * 60)
        print("🤖 Starting Multi-Agent Video Semantic Communication System")
        print("=" * 60)
        
        # Create all agents
        self.agents['cloud'] = CloudAgent("cloud_agent", self.message_bus)
        self.agents['edge'] = EdgeAgent("edge_agent", self.message_bus)
        self.agents['embodied'] = EmbodiedAgent("embodied_agent", self.message_bus, data_source="kitti")
        
        print("\n🚀 Starting agents...")
        for name, agent in self.agents.items():
             await agent.start()
    
        self.is_running = True
    
        
    async def run(self):
        print("\n🚀 System is running...")
        print("Press Ctrl+C to stop\n")
        
        await asyncio.sleep(1)
        
        task = "I want to extract vehicles from road videos captured by roadside cameras."
        await self.agents['cloud'].deploy_task(task)
        
        try:
            while self.is_running:
                await asyncio.sleep(1)
        except asyncio.CancelledError:
            pass
            
    async def shutdown(self):
        print("\n🛑 Shutting down system...")
        
        for name, agent in self.agents.items():
            await agent.stop()
            print(f"🛑 {name}_agent stopped")
            
        self.is_running = False
        print("✅ System shut down")

async def main():
    system = AgenticSystem()
    
    def signal_handler(signum, frame):
        print(f"\nReceived signal {signum}, shutting down...")
        asyncio.create_task(system.shutdown())
    
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    try:
        await system.setup()
        await system.run()
    finally:
        await system.shutdown()

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n👋 User interrupted")
        sys.exit(0)