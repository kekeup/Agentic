import asyncio
import json
import random
from datetime import datetime
from typing import Dict, Any, List
from pathlib import Path
import cv2
import numpy as np

from .base_agent import BaseAgent
from src.communication.protocols import MessageType
from src.datasets.kitti_loader import KITTIDataset

class EmbodiedAgent(BaseAgent):
    def __init__(self, agent_id: str, message_bus, data_source="kitti"):
        super().__init__(agent_id, message_bus)
        self.data_source = data_source
        self.device_type = "roadside_camera"
        self.location = "intersection_001"
        self.current_index = 0
        self.dataset = None
        
        # Load real KITTI dataset (road vehicle specific)
        self._initialize_kitti_dataset()
        
        
        if self.dataset:
            print(f"   Vehicle classes: {self.dataset.get_classes()[:5]}...")
    
    def _initialize_kitti_dataset(self):
        """Initialize local KITTI dataset"""
        try:
            print("📂 Loading local KITTI dataset...")
            self.dataset = KITTIDataset(
                data_dir="data/kitti",
                split="val",  # Use validation set for evaluation
                img_size=640,
                augment=False
            )
            self.current_index = 0
            
            print(f"✅ KITTI dataset loaded successfully")

            
        except Exception as e:
            print(f"❌ KITTI dataset loading failed: {e}")
            # Create empty dataset placeholder
            self.dataset = type('SimpleDataset', (), {
                '__len__': lambda self: 0,
                'get_class_name': lambda self, cls_id: f'class_{cls_id}'
            })()
    
    async def process_message(self, message):
        """Process received messages"""
        print(f"📥 {self.agent_id} received message type: {message.msg_type}")
        
        if message.msg_type == MessageType.JSON_CMD:
            await self._handle_json_command(message)
        elif message.msg_type == MessageType.TASK:
            await self._handle_task(message)
        else:
            print(f"⚠️  Ignoring unknown message type: {message.msg_type}")
    
    async def _handle_json_command(self, message):
        """Process JSON command - Retrieve real data from local KITTI dataset"""
        command = message.payload
        
        # Compatible with various command formats
        if "action" in command:
            action = command["action"]
        elif "command" in command:
            action = command["command"]
        else:
            action = ""
        
        print(f"📥 {self.agent_id} received JSON command: {action}")
        
        if action in ["data_retrieval", "retrieve_video", "get_data"]:
            # Execute real data retrieval
            params = command.get("parameters", {})
            num_frames = params.get("frame_count", 5)
            
            # Retrieve real data from local KITTI dataset
            data = await self._retrieve_real_kitti_data(num_frames)
            
            # Send data to Edge Agent
            await self.send_message(
                receiver="edge_agent",
                msg_type=MessageType.DATA,
                payload={
                    "data_type": "video",
                    "frames": data.get("frames", []),
                    "source": self.agent_id,
                    "command_id": command.get("command_id", ""),
                    "timestamp": datetime.now().isoformat(),
                    "data_source": "kitti_local",
                    "dataset_info": data.get("dataset_info", {})
                }
            )
    
    async def _retrieve_real_kitti_data(self, num_frames: int = 5) -> Dict[str, Any]:
        """Retrieve real road data from local KITTI dataset"""
        print(f"🎥 {self.agent_id} retrieving real road data from local KITTI dataset: {num_frames} frames")
        
        frames = []
        
        if self.dataset is None or len(self.dataset) == 0:
            print(f"❌ KITTI dataset not loaded or empty")
            return self._create_fallback_data(num_frames)
        
        try:
            total_samples = len(self.dataset)
            actual_frames = min(num_frames, total_samples)
            
            for i in range(actual_frames):
                if self.current_index >= total_samples:
                    self.current_index = 0
                
                idx = self.current_index
                
                # Get real KITTI data sample
                try:
                    sample = self.dataset[idx]
                except Exception as e:
                    print(f"⚠️  Failed to get sample {idx}: {e}")
                    self.current_index += 1
                    continue
                
                # Extract real annotation information
                annotations = []
                vehicle_count = 0
                
                if sample['boxes'].numel() > 0:
                    boxes = sample['boxes'].cpu().numpy()
                    for box in boxes:
                        if len(box) >= 5:
                            cls_id = int(box[0])
                            cx, cy, w, h = box[1:5]
                            
                            # Convert class ID to class name
                            try:
                                class_name = self.dataset.get_class_name(cls_id)
                            except:
                                # Default KITTI class mapping
                                class_names = {
                                    0: 'car', 1: 'van', 2: 'truck', 3: 'pedestrian',
                                    4: 'Person_sitting', 5: 'cyclist', 6: 'tram', 7: 'misc'
                                }
                                class_name = class_names.get(cls_id, f'class_{cls_id}')
                            
                            # Convert to pixel coordinates
                            if 'orig_size' in sample:
                                orig_h, orig_w = sample['orig_size'].cpu().numpy()
                            else:
                                orig_h, orig_w = 375, 1242  # KITTI default size
                            
                            x_center = cx * orig_w
                            y_center = cy * orig_h
                            width = w * orig_w
                            height = h * orig_h
                            
                            x1 = float(x_center - width / 2)
                            y1 = float(y_center - height / 2)
                            x2 = float(x_center + width / 2)
                            y2 = float(y_center + height / 2)
                            
                            # Check if it's a vehicle class
                            is_vehicle = cls_id in [0, 1, 2]  # car, van, truck
                            
                            annotation = {
                                "class_id": cls_id,
                                "class_name": class_name,
                                "bbox": [x1, y1, x2, y2],
                                "bbox_normalized": [float(cx), float(cy), float(w), float(h)],
                                "confidence": 1.0,
                                "is_vehicle": is_vehicle
                            }
                            
                            annotations.append(annotation)
                            
                            if is_vehicle:
                                vehicle_count += 1
                
                # Build frame data
                image_path = sample.get('img_path', f'kitti_sample_{idx}')
                
                frame_data = {
                    "frame_id": idx,
                    "image_path": str(image_path),
                    "vehicle_count": vehicle_count,
                    "annotations": annotations,
                    "timestamp": datetime.now().isoformat(),
                    "data_source": "kitti_local_real",
                    "dataset_name": "KITTI Real Dataset",
                    "description": f"Real KITTI road scene - sample {idx}",
                    "sample_info": {
                        "total_annotations": len(annotations),
                        "vehicle_annotations": vehicle_count,
                        "has_ground_truth": len(annotations) > 0
                    }
                }
                
                frames.append(frame_data)
                self.current_index += 1
            
            print(f"✅ Successfully retrieved {len(frames)} frames of real KITTI data")
            
            # Build dataset information
            dataset_info = {
                "name": "KITTI",
                "purpose": "Autonomous driving road vehicle detection",
                "description": "Real road scene vehicle detection dataset",
                "resolution": "1242x375 (original)",
                "vehicle_classes": ["car", "van", "truck"],
                "total_classes": 8,
                "source": "KITTI Benchmark Suite",
                "local_path": "data/kitti",
                "data_type": "real"
            }
            
            return {
                "status": "success",
                "data_source": "kitti_local_real",
                "frames": frames,
                "total_frames": len(frames),
                "dataset_info": dataset_info,
                "retrieval_info": {
                    "requested_frames": num_frames,
                    "delivered_frames": len(frames),
                    "current_index": self.current_index,
                    "timestamp": datetime.now().isoformat()
                }
            }
            
        except Exception as e:
            print(f"❌ KITTI real data retrieval failed: {e}")
            import traceback
            traceback.print_exc()
            
            # Return fallback data
            return self._create_fallback_data(num_frames)
    
    def _create_fallback_data(self, num_frames: int) -> Dict[str, Any]:
        """Create fallback data (when real data is not available)"""
        print(f"⚠️  Creating fallback data (real data not available)")
        
        frames = []
        for i in range(num_frames):
            # Create simple mock data
            vehicle_count = random.randint(1, 3)
            annotations = []
            for j in range(vehicle_count):
                annotations.append({
                    "class_id": random.randint(0, 2),
                    "class_name": ["car", "van", "truck"][random.randint(0, 2)],
                    "bbox": [random.randint(0, 1000), random.randint(0, 300), 
                            random.randint(100, 1100), random.randint(50, 350)],
                    "bbox_normalized": [random.random(), random.random(), 
                                       random.random()*0.2, random.random()*0.15],
                    "confidence": random.uniform(0.7, 0.95),
                    "is_vehicle": True
                })
            
            frames.append({
                "frame_id": i,
                "image_path": f"data/kitti/backup_frame_{i}.jpg",
                "vehicle_count": vehicle_count,
                "annotations": annotations,
                "timestamp": datetime.now().isoformat(),
                "data_source": "kitti_backup",
                "dataset_name": "KITTI Backup"
            })
        
        return {
            "status": "backup",
            "data_source": "kitti_backup",
            "frames": frames,
            "total_frames": len(frames),
            "dataset_info": {
                "name": "KITTI (Backup)",
                "purpose": "Road vehicle detection demonstration",
                "vehicle_classes": ["car", "van", "truck"],
                "note": "Real data not available, using mock data"
            }
        }
    
    async def _handle_task(self, message):
        """Handle task instructions"""
        task_config = message.payload
        print(f"📋 {self.agent_id} received task configuration")
        print(f"   Task type: {task_config.get('task', 'unknown')}")
        print(f"   Dataset: {task_config.get('dataset', 'kitti')}")
        print(f"   Model: {task_config.get('model', 'unknown')}")
        print(f"   Process: {task_config.get('training_pipeline', {}).get('method', 'unknown')}")
    
    def get_device_status(self) -> Dict[str, Any]:
        """Get device status"""
        return {
            "agent_id": self.agent_id,
            "device_type": self.device_type,
            "location": self.location,
            "status": "active",
            "data_source": self.data_source,
            "dataset_loaded": self.dataset is not None,
            "dataset_size": len(self.dataset) if self.dataset else 0,
            "current_index": self.current_index,
            "operation_mode": "real_data_retrieval",
            "timestamp": datetime.now().isoformat(),
            "capabilities": [
                "real_kitti_data_retrieval",
                "road_vehicle_annotation",
                "local_dataset_access"
            ]
        }