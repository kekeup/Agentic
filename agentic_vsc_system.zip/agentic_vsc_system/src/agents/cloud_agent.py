﻿import asyncio
import json
import yaml
from datetime import datetime
from typing import Dict, Any, List, Optional
from pathlib import Path
from .base_agent import BaseAgent
from src.communication.protocols import MessageType
import torch

class CloudAgent(BaseAgent):
    def __init__(self, agent_id: str, message_bus):
        super().__init__(agent_id, message_bus)
        self.config = self._load_system_config()
        self.model_state = "Model_A_COCO"
        self.model_coco_path = "models/yolov8n.pt"
        self.model_kitti_path = "models/model_b_kitti_ewc.pt"
        self.task_history = []
        self.model_history = []
        self.report_history = []
        self.openai_client = None
        
        # Initialize OpenAI
        self._init_openai()
        print(f"✅ Cloud Agent initialized")
        print(f"   OpenAI status: {'Enabled' if self.openai_client else 'Disabled'}")
        print(f"   Current model: {self.model_state}")
    
    def _load_system_config(self) -> Dict[str, Any]:
        """Load system configuration"""
        config_path = Path("config/system_config.yaml")
        if not config_path.exists():
            # Create default configuration
            config_path.parent.mkdir(parents=True, exist_ok=True)
            default_config = {
                'system': {'name': 'Agentic_VSC_System', 'version': '5.0'},
                'openai': {'enabled': False, 'api_key': '', 'model': 'gpt-4-turbo-preview'},
                'ewc': {'importance': 5000.0, 'training_epochs': 10, 'fisher_samples': 100},
                'thresholds': {'mAP': 0.35, 'snr_fluctuation': 3.0},
                'models': {
                    'base': 'models/yolov8n.pt',
                    'kitti_finetuned': 'models/model_b_kitti_ewc.pt'
                }
            }
            with open(config_path, 'w', encoding='utf-8') as f:
                yaml.dump(default_config, f, default_flow_style=False)
            return default_config
        
        with open(config_path, 'r', encoding='utf-8') as f:
            return yaml.safe_load(f)
    
    def _init_openai(self):
        """Initialize OpenAI client with proper API calls"""
        try:
            # Check if OpenAI is enabled
            openai_config = self.config.get('openai', {})
            if not openai_config.get('enabled', False):
                print("ℹ️  OpenAI is disabled, using local task parsing")
                return None
            
            # Check API key
            api_key = openai_config.get('api_key', '').strip()
            
            # Simple check: if not empty, try to initialize
            if not api_key:
                print("⚠️  OpenAI API key is empty, please check configuration")
                return None
            
            # Import openai library
            try:
                from openai import OpenAI
            except ImportError:
                print("❌ OpenAI library not installed, please run: pip install openai")
                return None
            
            # Create client with explicit configuration
            print(f"🔄 Initializing OpenAI client...")
            
            # Initialize client with the API key
            self.openai_client = OpenAI(
                api_key=api_key,
                timeout=30.0,  # 30 second timeout
                max_retries=3   # Retry up to 3 times
            )
            
            # Test connection with a simple API call
            try:
                # Use a simple models.list() call to test connection
                # Note: OpenAI's newer API doesn't support 'limit' parameter
                models_response = self.openai_client.models.list()
                
                # Check if we got any response
                if hasattr(models_response, 'data'):
                    model_count = len(models_response.data)
                    print(f"✅ OpenAI client initialized successfully")
                    print(f"   Available models: {model_count} models found")
                    print(f"   Using model: {openai_config.get('model', 'gpt-4-turbo-preview')}")
                    
                    # Save the client configuration
                    self.openai_config = {
                        'model': openai_config.get('model', 'gpt-4-turbo-preview'),
                        'temperature': openai_config.get('temperature', 0.7),
                        'max_tokens': openai_config.get('max_tokens', 1000)
                    }
                    
                    return self.openai_client
                else:
                    print("⚠️  OpenAI response format unexpected")
                    self.openai_client = None
                    return None
                    
            except Exception as e:
                error_msg = str(e)
                print(f"⚠️  OpenAI connection test failed: {type(e).__name__}")
                
                # Provide specific error messages
                if "Incorrect API key" in error_msg or "invalid_api_key" in error_msg:
                    print("❌ API key error, please check if the key is correct")
                elif "rate limit" in error_msg.lower():
                    print("⚠️  API rate limit reached, please try again later")
                elif "timeout" in error_msg.lower():
                    print("⚠️  Connection timeout, please check your network")
                elif "connect" in error_msg.lower():
                    print("⚠️  Connection error, please check your internet connection")
                else:
                    print(f"    Error details: {error_msg[:200]}")
                
                self.openai_client = None
                return None
        
        except Exception as e:
            print(f"❌ OpenAI initialization exception: {e}")
            self.openai_client = None
            return None
    
    async def process_message(self, message):
        """Process received messages"""
        print(f"📥 Cloud Agent received message: {message.msg_type.value}")
        
        if message.msg_type == MessageType.REPORT:
            await self._handle_report(message)
        elif message.msg_type == MessageType.ALERT:
            await self._handle_alert(message)
        elif message.msg_type == MessageType.PROMPT:
            await self._handle_prompt(message)
        else:
            print(f"📨 Cloud Agent received unknown message: {message.msg_type}")
    
    async def deploy_task(self, task_input: str):
        """Deploy new task"""
        print(f"🚀 Cloud Agent deploying new task: {task_input[:50]}...")
        
        # Parse task
        if self.openai_client:
            try:
                task_config = await self._parse_task_with_openai(task_input)
            except Exception as e:
                print(f"⚠️  OpenAI parsing failed, using local parsing: {e}")
                task_config = self._parse_task_locally(task_input)
        else:
            task_config = self._parse_task_locally(task_input)
        
        # Create task record
        task_id = f"task_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        task_config['task_id'] = task_id
        task_config['deployed_at'] = datetime.now().isoformat()
        
        task_record = {
            "task_id": task_id,
            "description": task_input,
            "config": task_config,
            "timestamp": datetime.now().isoformat(),
            "status": "deployed",
            "model_state_at_deploy": self.model_state
        }
        self.task_history.append(task_record)
        
        # 生成第2步的Prompt
        await self._generate_task_deployment_prompt(task_record)
        
        # Send to Edge Agent
        print(f"📤 Sending task to Edge Agent...")
        await self.send_message(
            receiver="edge_agent",
            msg_type=MessageType.TASK,
            payload=task_config
        )
        
        return task_record
    
    async def _generate_task_deployment_prompt(self, task_record: Dict[str, Any]):
        """生成任务部署时的Prompt（第2步）- 简化版本"""
        print("🔄 Generating Task Deployment Prompt (Step 2)...")
        
        # 创建简化的parsed_config，只包含指定字段
        simplified_parsed_config = {
            "task_type": task_record["config"].get('task_type', 'vehicle_extraction'),
            "model": task_record["config"].get('model', 'Model_A_COCO'),
            "dataset": task_record["config"].get('dataset', 'kitti')
        }
        
        # 创建简化的Prompt数据 - 只包含指定字段
        prompt_data = {
            "workflow_step": "2_Prompt",
            "task_id": task_record["task_id"],
            "task_description": task_record["description"],
            "parsed_config": simplified_parsed_config,
            "timestamp": datetime.now().isoformat(),
            "conditions": [
                f"Generate report when SNR fluctuation >= {self.config.get('thresholds', {}).get('snr_fluctuation', 3.0)} dB",
                f"Generate report when mAP < {self.config.get('thresholds', {}).get('mAP', 0.35)}"
            ]
        }
        
        # 保存Prompt到workflow_steps/prompts文件夹
        self._save_task_prompt(prompt_data)
        
        # 发送Prompt到Edge Agent
        print(f"📤 Sending Task Deployment Prompt to Edge Agent...")
        await self.send_message(
            receiver="edge_agent",
            msg_type=MessageType.PROMPT,
            payload=prompt_data
        )
        
        print(f"✅ Task Deployment Prompt (Step 2) generated and sent")
    
    def _save_task_prompt(self, prompt_data: Dict[str, Any]):
        """Save task prompt to workflow_steps/prompts directory"""
        try:
            prompt_dir = Path("workflow_steps/prompts")
            prompt_dir.mkdir(parents=True, exist_ok=True)
            
            task_id = prompt_data.get('task_id', f"task_{datetime.now().strftime('%Y%m%d_%H%M%S')}")
            prompt_path = prompt_dir / f"{task_id}_prompt.json"
            
            with open(prompt_path, 'w', encoding='utf-8') as f:
                json.dump(prompt_data, f, indent=2, ensure_ascii=False)
            print(f"📝 Task Prompt saved to: {prompt_path}")
            
        except Exception as e:
            print(f"⚠️  Failed to save Task Prompt: {e}")
    
    async def _parse_task_with_openai(self, description: str) -> Dict[str, Any]:
        """Parse task using OpenAI"""
        if not self.openai_client:
            return self._parse_task_locally(description)
        
        try:
            prompt = f"""
            Please parse the following video semantic communication task and return JSON configuration:
            
            Task description: "{description}"
            
            Return format:
            {{
                "task_type": "vehicle_extraction" | "vehicle_detection" | "performance_evaluation",
                "model": "Model_A_COCO" | "Model_B_KITTI_EWC",
                "dataset": "kitti",
                "description": "Task description",
                "evaluation_needed": true,
                "finetuning_needed": false,
                "report_needed": true,
                "thresholds": {{"map_threshold": 0.35, "snr_fluctuation": 3.0}}
            }}
            
            Important notes:
            1. Use Model_A_COCO by default unless task specifically mentions finetuning
            2. Always set report_needed to true
            3. Always set evaluation_needed to true
            """
            
            response = self.openai_client.chat.completions.create(
                model=self.openai_config.get('model', 'gpt-4-turbo-preview'),
                messages=[
                    {"role": "system", "content": "You are a video semantic communication system task parser"},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.3,
                max_tokens=500,
                response_format={"type": "json_object"}
            )
            
            content = response.choices[0].message.content
            
            try:
                config = json.loads(content)
                print(f"✅ OpenAI task parsing successful")
                return config
            except json.JSONDecodeError as e:
                print(f"⚠️  JSON parsing failed: {e}")
                return self._parse_task_locally(description)
            
        except Exception as e:
            print(f"⚠️  OpenAI parsing exception: {type(e).__name__}")
            print(f"    Error: {str(e)[:100]}")
            return self._parse_task_locally(description)
    
    def _parse_task_locally(self, description: str) -> Dict[str, Any]:
        """Local task parsing"""
        desc_lower = description.lower()
        
        config = {
            "task_type": "vehicle_extraction",
            "model": "Model_A_COCO",
            "dataset": "kitti",
            "description": description,
            "evaluation_needed": True,
            "finetuning_needed": False,
            "report_needed": True,
            "thresholds": {"map_threshold": 0.35, "snr_fluctuation": 3.0}
        }
        
        # Adjust configuration based on keywords
        if any(word in desc_lower for word in ["detect", "detection"]):
            config["task_type"] = "vehicle_detection"
        elif any(word in desc_lower for word in ["analyze", "evaluation", "performance"]):
            config["task_type"] = "performance_evaluation"
        elif any(word in desc_lower for word in ["monitor", "surveillance"]):
            config["task_type"] = "traffic_monitoring"
        
        if any(word in desc_lower for word in ["finetune", "finetuning", "adapt", "transfer"]):
            config["finetuning_needed"] = True
            config["model"] = "Model_B_KITTI_EWC"
        
        return config
    
    async def _handle_report(self, message):
        """Handle evaluation reports"""
        print("🔍 Cloud Agent processing evaluation report...")
        report_data = message.payload
        
        # Extract key information
        report_id = report_data.get('report_id', 'unknown')
        avg_map = report_data.get('summary', {}).get('average_mAP', 1.0)
        has_trigger = report_data.get('has_trigger', False)
        triggers = report_data.get('triggers', [])
        
        print(f"   Report ID: {report_id}")
        print(f"   Average mAP: {avg_map:.3f}")
        print(f"   Trigger conditions: {triggers}")
        
        # Save report to workflow_steps directory
        self._save_report_to_workflow(report_data)
        
        # Check if finetuning is needed
        map_threshold = report_data.get('thresholds', {}).get('map_threshold', 0.35)
        needs_finetuning = avg_map < map_threshold
        
        if needs_finetuning and has_trigger:
            print("🚀 mAP below threshold, triggering EWC finetuning...")
            success = await self._trigger_ewc_finetuning(report_data)
            
            if success:
                # 生成第8步的EWC完成Prompt
                await self._generate_ewc_completion_prompt()
                await self._send_model_switch_instruction()
            else:
                print("❌ EWC finetuning failed")
        else:
            print("✅ mAP normal, no finetuning needed")
        
        # Record report
        report_record = {
            "report_id": report_id,
            "processed_at": datetime.now().isoformat(),
            "average_mAP": avg_map,
            "needs_finetuning": needs_finetuning,
            "action_taken": "EWC finetuning" if needs_finetuning else "No action",
            "triggers": triggers
        }
        self.report_history.append(report_record)
        
        print(f"📝 Report processing completed")
    
    async def _generate_ewc_completion_prompt(self):
        """Generate EWC completion prompt """
        
        # CreatebEWC Prompt ID
        ewc_prompt_id = f"ewc_prompt_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        current_timestamp = datetime.now().isoformat()
        
        ewc_prompt_data = {
            "workflow_step": "8_Prompt",
            "prompt_id": ewc_prompt_id,
            "prompt_content": "EWC finetuning completed. Model B (KITTI-EWC) is now available for use.",
            "timestamp": current_timestamp,
            "ewc_status": "completed",
            "model_b_status": "available"
        }
        
        self._save_ewc_prompt(ewc_prompt_data)
        
        print(f"📤 Sending EWC Completion Prompt to Edge Agent...")
        await self.send_message(
            receiver="edge_agent",
            msg_type=MessageType.PROMPT,
            payload=ewc_prompt_data
        )
        
    def _save_ewc_prompt(self, ewc_prompt_data: Dict[str, Any]):
        """Save EWC completion prompt to workflow_steps/ewc_prompts directory"""
        try:
            ewc_prompt_dir = Path("workflow_steps/ewc_prompts")
            ewc_prompt_dir.mkdir(parents=True, exist_ok=True)
            
            prompt_id = ewc_prompt_data.get('prompt_id', f"ewc_prompt_{datetime.now().strftime('%Y%m%d_%H%M%S')}")
            ewc_prompt_path = ewc_prompt_dir / f"{prompt_id}.json"
            
            with open(ewc_prompt_path, 'w', encoding='utf-8') as f:
                json.dump(ewc_prompt_data, f, indent=2, ensure_ascii=False)
            print(f"📝 EWC Completion Prompt saved to: {ewc_prompt_path}")
            
        except Exception as e:
            print(f"⚠️  Failed to save EWC Completion Prompt: {e}")
    
    def _save_report_to_workflow(self, report_data: Dict[str, Any]):
        """Save report to workflow_steps directory"""
        try:
            reports_dir = Path("workflow_steps/reports")
            reports_dir.mkdir(parents=True, exist_ok=True)
            
            report_id = report_data.get('report_id', f"report_{datetime.now().strftime('%Y%m%d_%H%M%S')}")
            report_path = reports_dir / f"{report_id}.json"
            
            # Enhance report data with system information
            enhanced_report = {
                **report_data,
                "processed_by": "cloud_agent",
                "processing_timestamp": datetime.now().isoformat(),
                "system_version": self.config.get('system', {}).get('version', '5.0'),
                "model_state": self.model_state
            }
            
            with open(report_path, 'w', encoding='utf-8') as f:
                json.dump(enhanced_report, f, indent=2, ensure_ascii=False)
            print(f"📝 Report saved to workflow steps: {report_path}")
            
        except Exception as e:
            print(f"⚠️  Failed to save report to workflow steps: {e}")
    
    async def _trigger_ewc_finetuning(self, report_data: Dict[str, Any]) -> bool:
        """Trigger EWC finetuning"""
        print("🔄 Triggering EWC finetuning...")
        
        try:
            # Import EWC trainer
            try:
                from src.core.ewc_trainer import RealEWCTrainer
                print("✅ EWC trainer imported successfully")
            except ImportError as e:
                print(f"❌ EWC trainer import failed: {e}")
                return False
            
            # Get configuration
            ewc_config = self.config.get('ewc', {})
            importance = ewc_config.get('importance', 5000.0)
            fisher_samples = ewc_config.get('fisher_samples', 100)
            training_epochs = ewc_config.get('training_epochs', 10)
            batch_size = ewc_config.get('batch_size', 8)
            
            print(f"🔧 EWC configuration: importance={importance}, samples={fisher_samples}, epochs={training_epochs}")
            
            # Check model file
            if not Path(self.model_coco_path).exists():
                print(f"❌ Base model does not exist: {self.model_coco_path}")
                print("   Attempting to download YOLOv8 model...")
                try:
                    import subprocess
                    result = subprocess.run(
                        ["python", "-c", "from ultralytics import YOLO; YOLO('yolov8n.pt')"],
                        capture_output=True,
                        text=True
                    )
                    if result.returncode == 0:
                        Path("models").mkdir(exist_ok=True)
                        print("✅ YOLOv8 model downloaded successfully")
                    else:
                        print("❌ YOLOv8 model download failed")
                        return False
                except Exception as e:
                    print(f"❌ Model download exception: {e}")
                    return False
            
            # Create trainer
            print("🏗️  Creating EWC trainer...")
            trainer = RealEWCTrainer(
                model_path=self.model_coco_path,
                importance=importance,
                device='cuda' if torch.cuda.is_available() else 'cpu'
            )
            
            # Compute Fisher matrix
            print("📊 Computing Fisher matrix...")
            fisher_success = trainer.compute_fisher_matrix(
                coco_data_dir="data/coco",
                num_samples=fisher_samples
            )
            
            if not fisher_success:
                print("⚠️  Fisher matrix computation failed, using backup method...")
                fisher_success = trainer._compute_fisher_simple(num_samples=50)
            
            # Execute finetuning
            print("🔄 Executing KITTI finetuning...")
            training_results = trainer.finetune_on_kitti(
                epochs=training_epochs,
                batch_size=batch_size
            )
            
            # Check results
            status = training_results.get('status', '')
            if status in ['success', 'success_fallback']:
                self.model_state = "Model_B_KITTI_EWC"
                self.model_kitti_path = training_results.get('model_path', 'models/model_b_kitti_ewc.pt')
                
                # Record model switch
                model_record = {
                    "from_model": "Model_A_COCO",
                    "to_model": "Model_B_KITTI_EWC",
                    "method": training_results.get('method', 'EWC'),
                    "timestamp": datetime.now().isoformat(),
                    "trigger_reason": f"mAP: {report_data.get('summary', {}).get('average_mAP', 0):.3f} < 0.35",
                    "training_results": training_results
                }
                self.model_history.append(model_record)
                
                print(f"✅ EWC finetuning successful! New model: {self.model_kitti_path}")
                return True
            else:
                print(f"❌ EWC finetuning failed: {training_results}")
                return False
                
        except Exception as e:
            print(f"❌ EWC finetuning exception: {e}")
            import traceback
            traceback.print_exc()
            return False
    
    async def _send_model_switch_instruction(self):
        """Send model switch instruction (JSON command)"""
        
        switch_prompt = {
            "workflow_step": "JSON_Switch",
            "action": "switch_model",
            "old_model": "Model_A_COCO",
            "new_model": "Model_B_KITTI_EWC",
            "model_path": self.model_kitti_path,
            "timestamp": datetime.now().isoformat(),
            "reason": "EWC finetuning completed",
            "status": "ready",
            "command_type": "model_switch",
            "parameters": {
                "threshold_triggered": "mAP < 0.35",
                "ewc_training_completed": True
            }
        }
        
        
        await self.send_message(
            receiver="edge_agent",
            msg_type=MessageType.PROMPT,
            payload=switch_prompt
        )
        
    
    def _save_json_command(self, json_data: Dict[str, Any]):
        """Save JSON command to workflow_steps directory"""
        try:
            json_dir = Path("workflow_steps/json_commands")
            json_dir.mkdir(parents=True, exist_ok=True)
            
            command_id = json_data.get('action', f"command_{datetime.now().strftime('%Y%m%d_%H%M%S')}")
            json_path = json_dir / f"{command_id}.json"
            
            with open(json_path, 'w', encoding='utf-8') as f:
                json.dump(json_data, f, indent=2, ensure_ascii=False)
            print(f"📝 JSON command saved to: {json_path}")
            
        except Exception as e:
            print(f"⚠️  Failed to save JSON command: {e}")
    
    async def _handle_alert(self, message):
        """Handle alerts"""
        print("⚠️  Processing alert message")
        alert_data = message.payload
        print(f"   Alert type: {alert_data.get('alert_type', 'unknown')}")
        print(f"   Message: {alert_data.get('message', 'none')}")
    
    async def _handle_prompt(self, message):
        """Handle prompt messages"""
        print("💬 Processing prompt message")
        prompt_data = message.payload
        
        # 检查不同类型的Prompt
        if prompt_data.get('workflow_step') == '8_Prompt':
            print("✅ Received EWC Completion Prompt (Step 8):")
            print(f"   Message: {prompt_data.get('prompt_content', 'none')}")
            print(f"   EWC Status: {prompt_data.get('ewc_status', 'unknown')}")
            print(f"   Model B Status: {prompt_data.get('model_b_status', 'unknown')}")
        elif prompt_data.get('workflow_step') == '2_Prompt':
            print("📋 Received Task Deployment Prompt (Step 2)")
            print(f"   Task ID: {prompt_data.get('task_id', 'unknown')}")
            print(f"   Task Description: {prompt_data.get('task_description', 'none')[:50]}...")
            print(f"   Task Type: {prompt_data.get('parsed_config', {}).get('task_type', 'unknown')}")
        else:
            print(f"   General Prompt: {prompt_data.get('message', 'none')}")
    
    def get_system_status(self) -> Dict[str, Any]:
        """Get system status"""
        return {
            "agent_id": self.agent_id,
            "model_state": self.model_state,
            "task_count": len(self.task_history),
            "model_switches": len(self.model_history),
            "openai_enabled": self.openai_client is not None,
            "report_count": len(self.report_history),
            "ewc_prompt_count": len(list(Path("workflow_steps/ewc_prompts").glob("*.json"))) if Path("workflow_steps/ewc_prompts").exists() else 0,
            "status": "active",
            "workflow_steps_created": {
                "prompts": len(list(Path("workflow_steps/prompts").glob("*.json"))) if Path("workflow_steps/prompts").exists() else 0,
                "ewc_prompts": len(list(Path("workflow_steps/ewc_prompts").glob("*.json"))) if Path("workflow_steps/ewc_prompts").exists() else 0,
                "json_commands": len(list(Path("workflow_steps/json_commands").glob("*.json"))) if Path("workflow_steps/json_commands").exists() else 0,
                "reports": len(list(Path("workflow_steps/reports").glob("*.json"))) if Path("workflow_steps/reports").exists() else 0
            }
        }

    def get_task_history_summary(self) -> Dict[str, Any]:
        """Get task history summary"""
        return {
            "total_tasks": len(self.task_history),
            "tasks": self.task_history[-5:] if self.task_history else [],  # Last 5 tasks
            "successful_ewc_finetunings": len([h for h in self.model_history if "EWC" in str(h.get('method', ''))]),
            "ewc_prompts_generated": len(list(Path("workflow_steps/ewc_prompts").glob("*.json"))) if Path("workflow_steps/ewc_prompts").exists() else 0
        }
