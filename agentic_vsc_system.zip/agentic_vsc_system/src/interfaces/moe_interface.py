from typing import Dict, Any, List, Optional
import random
from datetime import datetime

class MoEInterface:
    """MoE Gating Network Interface Class """
    
    def __init__(self, num_experts: int = 2):

        self.num_experts = num_experts
        self.experts = [f"Expert_{i}" for i in range(num_experts)]
        self.interface_status = "ready"
        self.selection_history = []
        
    def select_expert(self, features: List[float] = None) -> Dict[str, Any]:
        if features is None:
            features = [0.5] * 10  # Default feature vector
        
        selected_idx = random.randint(0, self.num_experts - 1)
        confidence = random.uniform(0.7, 0.95)  # Simulate confidence
        
        selection_result = {
            "selected_expert": self.experts[selected_idx],
            "expert_id": selected_idx,
            "confidence": confidence,
            "experts_available": self.num_experts,
            "features_received": len(features),
            "interface": "MoE_Gating_Network",
            "status": "interface_ready",
            "timestamp": datetime.now().isoformat(),
            "selection_logic": "random_selection_for_interface"
        }
        
        
        self.selection_history.append(selection_result)
        if len(self.selection_history) > 100:
            self.selection_history = self.selection_history[-100:]
        
        return selection_result
    
    def get_expert_info(self, expert_id: int) -> Dict[str, Any]:
        """Get expert information"""
        if 0 <= expert_id < self.num_experts:
            return {
                "expert_id": expert_id,
                "name": self.experts[expert_id],
                "specialization": f"Model_{['A', 'B'][expert_id % 2]}",
                "capabilities": ["object_detection", "feature_extraction"],
                "status": "available",
                "is_interface": True
            }
        else:
            return {
                "error": f"Expert ID {expert_id} does not exist",
                "available_experts": self.num_experts
            }
    
    def get_selection_statistics(self) -> Dict[str, Any]:
        """Get selection statistics"""
        if not self.selection_history:
            return {"total_selections": 0}
        
        # Count the number of times each expert is selected
        expert_counts = {expert: 0 for expert in self.experts}
        total_selections = len(self.selection_history)
        
        for selection in self.selection_history:
            expert_name = selection.get("selected_expert", "")
            if expert_name in expert_counts:
                expert_counts[expert_name] += 1
        
        # Calculate percentages
        statistics = {"total_selections": total_selections}
        for expert, count in expert_counts.items():
            percentage = (count / total_selections * 100) if total_selections > 0 else 0
            statistics[expert] = {
                "count": count,
                "percentage": round(percentage, 1)
            }
        
        return statistics
    
    def get_interface_info(self) -> Dict[str, Any]:
        """Get interface information"""
        return {
            "name": "MoEInterface",
            "purpose": "Mixture of Experts gating network interface",
            "status": self.interface_status,
            "num_experts": self.num_experts,
            "expert_names": self.experts,
            "implementation_status": "interface_only",
            "compliance": "MoE"
        }
    
    def reset(self):
        self.selection_history = []
        print("🔄 MoE interface has been reset")