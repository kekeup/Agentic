from typing import Dict, Any, List
from datetime import datetime
import random

class SNRMonitorInterface:
    
    def __init__(self, threshold: float = 3.0):

        self.threshold = threshold
        self.interface_status = "ready"
        self.measurement_history = []
        
        print(f"📡 SNR监控接口初始化")
        print(f"   接口状态: {self.interface_status}")
        print(f"   阈值: {threshold} dB")
        print(f"   说明: 这是接口定义，实际硬件实现时可替换")
    
    def measure(self) -> Dict[str, Any]:
        measurement = {
            "value": 22.5 + random.uniform(-1, 1),  # 模拟值，实际应替换
            "threshold": self.threshold,
            "unit": "dB",
            "interface": "SNR_Measurement_Tool",
            "status": "interface_ready",
            "hardware_required": True,
            "timestamp": datetime.now().isoformat(),
            "note": "这是SNR监控接口定义，实际硬件实现时需提供真实测量值"
        }
        
        # 记录历史
        self.measurement_history.append(measurement)
        if len(self.measurement_history) > 100:
            self.measurement_history = self.measurement_history[-100:]
        
        return measurement
    
    def check_fluctuation(self, current_snr: float = None) -> Dict[str, Any]:
        """
        检查SNR波动 - 接口定义
        
        参数:
            current_snr: 当前SNR值（可选）
            
        返回:
            波动检查结果
        """
        if current_snr is None:
            # 如果没有提供当前值，先测量一次
            measurement = self.measure()
            current_snr = measurement["value"]
        
        # 计算波动（基于历史记录）
        fluctuation = 0.0
        should_trigger = False
        
        if len(self.measurement_history) >= 2:
            # 计算最近几次测量的波动
            recent_values = [m["value"] for m in self.measurement_history[-5:]]
            if recent_values:
                max_val = max(recent_values)
                min_val = min(recent_values)
                fluctuation = max_val - min_val
                should_trigger = fluctuation >= self.threshold
        
        return {
            "current_snr": current_snr,
            "threshold": self.threshold,
            "fluctuation": fluctuation,
            "fluctuation_detected": should_trigger,
            "should_trigger_report": should_trigger,
            "interface": "SNR_Fluctuation_Check",
            "status": "interface_ready",
            "timestamp": datetime.now().isoformat()
        }
    
    def get_measurement_history(self, limit: int = 10) -> List[Dict[str, Any]]:
        """获取测量历史"""
        return self.measurement_history[-limit:] if self.measurement_history else []
    
    def get_interface_info(self) -> Dict[str, Any]:
        """获取接口信息"""
        return {
            "name": "SNRMonitorInterface",
            "purpose": "Signal-to-Noise Ratio monitoring interface",
            "status": self.interface_status,
            "threshold": self.threshold,
            "required_hardware": "RF measurement equipment",
            "implementation_status": "interface_only",
            "compliance": "2,
            "note": "接口"
        }
    
    def reset(self):
        """重置接口"""
        self.measurement_history = []
        print("🔄 SNR接口已重置")