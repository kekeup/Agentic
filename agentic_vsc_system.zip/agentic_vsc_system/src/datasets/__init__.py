# 修改后的 src/datasets/__init__.py
"""
数据集模块初始化文件
统一的数据集接口
"""

# COCO数据集
from .coco_loader import (
    RealCOCODataset,           # 真实COCO数据集加载器
    create_coco_dataloader,    # 创建COCO数据加载器
    test_coco_dataset,         # 测试COCO数据集
    # get_coco_vehicle_stats,   # ❌ 删除这行，函数不存在
    YOLOCOCOLoader             # 兼容性别名
)

# KITTI数据集
from .kitti_loader import (
    KITTIDataset,              # KITTI数据集
    create_kitti_dataloader,   # 创建KITTI数据加载器
    test_kitti_dataset,        # 测试KITTI数据集
    get_dataset_statistics     # 获取数据集统计
)

__all__ = [
    # COCO相关
    'RealCOCODataset',
    'create_coco_dataloader',
    'test_coco_dataset',
    'YOLOCOCOLoader',
    
    # KITTI相关
    'KITTIDataset',
    'create_kitti_dataloader',
    'test_kitti_dataset',
    'get_dataset_statistics'
]

# 版本信息
__version__ = '2.0.0'
__author__ = 'Agentic VSC System'
__description__ = '数据集加载器 - COCO & KITTI'