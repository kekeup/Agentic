import os
import cv2
import numpy as np
from pathlib import Path
from typing import List, Dict, Any, Optional
import torch
from torch.utils.data import Dataset, DataLoader
import yaml
import random

class RealCOCODataset(Dataset):

    VEHICLE_CLASS_IDS = {
        2: "car",
        3: "motorcycle", 
        5: "bus",
        7: "truck",
        8: "boat",
        9: "traffic light"
    }
    VEHICLE_CLASS_KEYS = list(VEHICLE_CLASS_IDS.keys())
    
    def __init__(self, data_dir="data/coco", split="val2014", img_size=640):
        self.data_dir = Path(data_dir)
        self.split = split
        self.img_size = img_size
        
        # Instance attributes pointing to class attributes
        self.vehicle_class_ids = self.VEHICLE_CLASS_IDS
        
        # Load COCO configuration
        self.config = self._load_config()
        
        # Get image and label files
        self.image_files = self._get_image_files()
        self.label_files = self._get_label_files()
        
        print(f"✅ Real COCO dataset loaded: {split}")
        print(f"   Number of images: {len(self.image_files)}")
        print(f"   Vehicle classes: {list(self.vehicle_class_ids.values())}")
    
    def _load_config(self):
        """Load COCO configuration file"""
        config_path = self.data_dir / "coco.yaml"
        
        if config_path.exists():
            with open(config_path, 'r', encoding='utf-8') as f:
                return yaml.safe_load(f)
        else:
            # Create default configuration
            config = {
                'path': str(self.data_dir),
                'train': 'images/train2014',
                'val': 'images/val2014',
                'nc': 80,  # COCO has 80 classes
                'names': [
                    'person', 'bicycle', 'car', 'motorcycle', 'airplane', 'bus', 'train', 'truck',
                    'boat', 'traffic light', 'fire hydrant', 'stop sign', 'parking meter', 'bench',
                    'bird', 'cat', 'dog', 'horse', 'sheep', 'cow', 'elephant', 'bear', 'zebra',
                    'giraffe', 'backpack', 'umbrella', 'handbag', 'tie', 'suitcase', 'frisbee',
                    'skis', 'snowboard', 'sports ball', 'kite', 'baseball bat', 'baseball glove',
                    'skateboard', 'surfboard', 'tennis racket', 'bottle', 'wine glass', 'cup',
                    'fork', 'knife', 'spoon', 'bowl', 'banana', 'apple', 'sandwich', 'orange',
                    'broccoli', 'carrot', 'hot dog', 'pizza', 'donut', 'cake', 'chair', 'couch',
                    'potted plant', 'bed', 'dining table', 'toilet', 'tv', 'laptop', 'mouse',
                    'remote', 'keyboard', 'cell phone', 'microwave', 'oven', 'toaster', 'sink',
                    'refrigerator', 'book', 'clock', 'vase', 'scissors', 'teddy bear', 'hair drier',
                    'toothbrush'
                ]
            }
            
            # Save configuration
            with open(config_path, 'w', encoding='utf-8') as f:
                yaml.dump(config, f, default_flow_style=False)
            
            print(f"📄 Created COCO configuration file: {config_path}")
            return config
    
    def _get_image_files(self):
        """Get list of image files"""
        image_dir = self.data_dir / "images" / self.split
        
        if not image_dir.exists():
            print(f"⚠️  Image directory does not exist: {image_dir}")
            print(f"   Creating sample images in {image_dir}...")
            image_dir.mkdir(parents=True, exist_ok=True)
            
            # Create some sample images
            return self._create_sample_images(image_dir, count=20)
        
        # Get all image files
        image_extensions = ['.jpg', '.jpeg', '.png', '.bmp']
        image_files = []
        
        for ext in image_extensions:
            image_files.extend(list(image_dir.rglob(f"*{ext}")))
        
        # Limit number for testing
        image_files = sorted(image_files)
        
        return image_files
    
    def _get_label_files(self):
        """Get list of label files"""
        label_dir = self.data_dir / "labels" / self.split
        
        # If label directory doesn't exist, create sample labels
        if not label_dir.exists():
            label_dir.mkdir(parents=True, exist_ok=True)
            print(f"📝 Created sample label directory: {label_dir}")
        
        label_files = []
        for img_path in self.image_files:
            label_path = label_dir / f"{img_path.stem}.txt"
            label_files.append(label_path)
            
            # If label file doesn't exist, create sample label
            if not label_path.exists():
                self._create_sample_label(label_path, img_path)
        
        return label_files
    
    def _create_sample_images(self, image_dir, count=20):
        """Create sample images"""
        image_files = []
        
        for i in range(count):
            # Create random size images
            width = random.choice([640, 800, 1024])
            height = random.choice([480, 600, 768])
            
            # Create image with random objects
            img = np.zeros((height, width, 3), dtype=np.uint8) + random.randint(100, 200)
            
            # Randomly add some "vehicles"
            for _ in range(random.randint(0, 3)):
                x1 = random.randint(0, width - 100)
                y1 = random.randint(0, height - 80)
                x2 = x1 + random.randint(50, 100)
                y2 = y1 + random.randint(40, 80)
                
                color = (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255))
                cv2.rectangle(img, (x1, y1), (x2, y2), color, -1)
            
            img_path = image_dir / f"coco_sample_{i:04d}.jpg"
            cv2.imwrite(str(img_path), img)
            image_files.append(img_path)
        
        print(f"📷 Created {len(image_files)} sample images")
        return image_files
    
    def _create_sample_label(self, label_path, img_path):
        """Create sample label file"""
        # Randomly generate some vehicle annotations
        num_objects = random.randint(1, 3)  # Ensure at least 1
        
        with open(label_path, 'w') as f:
            for _ in range(num_objects):
                # Randomly select vehicle class
                class_id = random.choice(list(self.vehicle_class_ids.keys()))
                
                # Randomly generate normalized bounding boxes
                cx = random.uniform(0.2, 0.8)
                cy = random.uniform(0.2, 0.8)
                w = random.uniform(0.05, 0.2)
                h = random.uniform(0.05, 0.15)
                
                f.write(f"{class_id} {cx:.6f} {cy:.6f} {w:.6f} {h:.6f}\n")
        
        print(f"📝 Created label: {label_path.name}, number of vehicles: {num_objects}")
    
    def __len__(self):
        return len(self.image_files)
    
    def __getitem__(self, idx):
        # Get image file path
        img_path = self.image_files[idx]
        label_path = self.label_files[idx]
        
        # Load image
        try:
            img = cv2.imread(str(img_path))
            if img is None:
                # Create random image
                img = np.zeros((480, 640, 3), dtype=np.uint8) + 128
                print(f"⚠️  Unable to read image: {img_path}")
        except Exception as e:
            print(f"⚠️  Image reading error: {e}")
            img = np.zeros((480, 640, 3), dtype=np.uint8) + 128
        
        orig_h, orig_w = img.shape[:2]
        
        # Resize image
        img = cv2.resize(img, (self.img_size, self.img_size))
        
        # Convert to PyTorch format
        img = img[:, :, ::-1].transpose(2, 0, 1)  # BGR to RGB, HWC to CHW
        img = np.ascontiguousarray(img) / 255.0
        
        # Load labels
        boxes = []
        if label_path.exists():
            try:
                with open(label_path, 'r') as f:
                    for line in f:
                        line = line.strip()
                        if line:
                            parts = line.split()
                            if len(parts) >= 5:
                                class_id = int(parts[0])
                                cx, cy, w, h = map(float, parts[1:5])
                                
                                # Keep only vehicle classes
                                if class_id in self.vehicle_class_ids:
                                    boxes.append([class_id, cx, cy, w, h])
            except Exception as e:
                print(f"⚠️  Label reading error: {e}")
        
        # Convert to Tensor
        img_tensor = torch.from_numpy(img).float()
        
        if boxes:
            boxes_tensor = torch.tensor(boxes, dtype=torch.float32)
        else:
            boxes_tensor = torch.zeros((0, 5), dtype=torch.float32)
        
        return {
            'image': img_tensor,
            'boxes': boxes_tensor,
            'img_path': str(img_path),
            'orig_size': torch.tensor([orig_h, orig_w])
        }
    
    def get_class_name(self, class_id):
        """Get class name"""
        if 0 <= class_id < len(self.config['names']):
            return self.config['names'][class_id]
        return f"class_{class_id}"
    
    def is_vehicle_class(self, class_id):
        """Check if it's a vehicle class"""
        return class_id in self.vehicle_class_ids

def create_coco_dataloader(data_dir="data/coco", split="val2014", 
                          batch_size=8, img_size=640, shuffle=False):
    """
    Create COCO data loader
    
    Returns:
        DataLoader, Dataset
    """
    dataset = RealCOCODataset(
        data_dir=data_dir,
        split=split,
        img_size=img_size
    )
    
    def collate_fn(batch):
        images = []
        boxes_list = []
        img_paths = []
        orig_sizes = []
        
        for item in batch:
            images.append(item['image'])
            boxes_list.append(item['boxes'])
            img_paths.append(item['img_path'])
            orig_sizes.append(item['orig_size'])
        
        images = torch.stack(images, 0)
        
        return {
            'image': images,
            'boxes': boxes_list,
            'img_path': img_paths,
            'orig_size': torch.stack(orig_sizes, 0)
        }
    
    dataloader = DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=shuffle,
        collate_fn=collate_fn,
        num_workers=0
    )
    
    return dataloader, dataset

def test_coco_dataset():
    """Test COCO dataset"""
    print("🧪 Testing real COCO dataset...")
    
    try:
        dataloader, dataset = create_coco_dataloader(
            data_dir="data/coco",
            split="val2014",
            batch_size=2,
            img_size=640
        )
        
        print(f"✅ Dataset size: {len(dataset)}")
        
        # Get one batch
        batch = next(iter(dataloader))
        print(f"✅ Batch image shape: {batch['image'].shape}")
        
        # Count number of vehicles
        vehicle_count = 0
        for boxes in batch['boxes']:
            for box in boxes:
                if len(box) >= 1 and dataset.is_vehicle_class(int(box[0])):
                    vehicle_count += 1
        
        print(f"✅ Number of vehicle detections: {vehicle_count}")
        
        return True
        
    except Exception as e:
        print(f"❌ Test failed: {e}")
        import traceback
        traceback.print_exc()
        return False

# ============================================================================
# Compatibility aliases
# ============================================================================

# For backward compatibility, export RealCOCODataset as YOLOCOCOLoader
# So old import code doesn't need modification
YOLOCOCOLoader = RealCOCODataset

# If there was originally a get_vehicle_images method, need to add it to new class
def get_vehicle_images(self, split="val2014", max_samples=20):
    """Compatibility method: Get images containing vehicles"""
    print(f"⚠️  Using compatibility method, recommend using create_coco_dataloader instead")
    
    # Create data loader to get data
    from .coco_loader import create_coco_dataloader
    dataloader, dataset = create_coco_dataloader(
        split=split.replace("2014", "") if "2014" in split else split,
        batch_size=1,
        img_size=640,
        shuffle=True
    )
    
    vehicle_images = []
    for i, batch in enumerate(dataloader):
        if i >= max_samples:
            break
        
        image_path = batch['img_path'][0]
        boxes = batch['boxes'][0]
        
        # Count number of vehicles
        vehicle_count = 0
        vehicle_annotations = []
        
        for box in boxes:
            if len(box) >= 5:
                class_id = int(box[0])
                # Check if it's a vehicle class
                if class_id in [2, 3, 5, 7]:  # car, motorcycle, bus, truck
                    vehicle_count += 1
                    
                    cx, cy, w, h = box[1:5].tolist()
                    orig_h, orig_w = batch['orig_size'][0].tolist()
                    
                    # Convert to pixel coordinates
                    x_center = cx * orig_w
                    y_center = cy * orig_h
                    width = w * orig_w
                    height = h * orig_h
                    
                    x1 = x_center - width / 2
                    y1 = y_center - height / 2
                    x2 = x_center + width / 2
                    y2 = y_center + height / 2
                    
                    vehicle_annotations.append({
                        "class_id": class_id,
                        "class_name": dataset.get_class_name(class_id),
                        "bbox": [float(x1), float(y1), float(x2), float(y2)],
                        "bbox_normalized": [float(cx), float(cy), float(w), float(h)],
                        "area": float(width * height)
                    })
        
        vehicle_images.append({
            "image_path": image_path,
            "num_vehicles": vehicle_count,
            "vehicle_annotations": vehicle_annotations,
            "width": int(orig_w),
            "height": int(orig_h),
            "split": split
        })
    
    return vehicle_images

# Add compatibility method to class
RealCOCODataset.get_vehicle_images = get_vehicle_images
YOLOCOCOLoader.get_vehicle_images = get_vehicle_images

if __name__ == "__main__":
    test_coco_dataset()