
import os
import cv2
import numpy as np
from pathlib import Path
from typing import List, Dict, Any, Optional
import torch
from torch.utils.data import Dataset, DataLoader
import yaml
import random

class RealCOCODataset(Dataset):

    VEHICLE_CLASS_IDS = {
        2: "car",
        3: "motorcycle", 
        5: "bus",
        7: "truck",
        8: "boat",
        9: "traffic light"
    }
    VEHICLE_CLASS_KEYS = list(VEHICLE_CLASS_IDS.keys())
    
    def __init__(self, data_dir="data/coco", split="val2014", img_size=640):
        """
        参数:
            data_dir: COCO数据目录
            split: 'train2014' 或 'val2014'
            img_size: 图像尺寸
        """
        self.data_dir = Path(data_dir)
        self.split = split
        self.img_size = img_size
        
        # 实例属性，指向类属性
        self.vehicle_class_ids = self.VEHICLE_CLASS_IDS
        
        # 加载COCO配置
        self.config = self._load_config()
        
        # 获取图像和标签文件
        self.image_files = self._get_image_files()
        self.label_files = self._get_label_files()
        
        print(f"✅ 真实COCO数据集加载: {split}")
        print(f"   图像数量: {len(self.image_files)}")
        print(f"   车辆类别: {list(self.vehicle_class_ids.values())}")
    
    def _load_config(self):
        """加载COCO配置文件"""
        config_path = self.data_dir / "coco.yaml"
        
        if config_path.exists():
            with open(config_path, 'r', encoding='utf-8') as f:
                return yaml.safe_load(f)
        else:
            # 创建默认配置
            config = {
                'path': str(self.data_dir),
                'train': 'images/train2014',
                'val': 'images/val2014',
                'nc': 80,  # COCO有80个类别
                'names': [
                    'person', 'bicycle', 'car', 'motorcycle', 'airplane', 'bus', 'train', 'truck',
                    'boat', 'traffic light', 'fire hydrant', 'stop sign', 'parking meter', 'bench',
                    'bird', 'cat', 'dog', 'horse', 'sheep', 'cow', 'elephant', 'bear', 'zebra',
                    'giraffe', 'backpack', 'umbrella', 'handbag', 'tie', 'suitcase', 'frisbee',
                    'skis', 'snowboard', 'sports ball', 'kite', 'baseball bat', 'baseball glove',
                    'skateboard', 'surfboard', 'tennis racket', 'bottle', 'wine glass', 'cup',
                    'fork', 'knife', 'spoon', 'bowl', 'banana', 'apple', 'sandwich', 'orange',
                    'broccoli', 'carrot', 'hot dog', 'pizza', 'donut', 'cake', 'chair', 'couch',
                    'potted plant', 'bed', 'dining table', 'toilet', 'tv', 'laptop', 'mouse',
                    'remote', 'keyboard', 'cell phone', 'microwave', 'oven', 'toaster', 'sink',
                    'refrigerator', 'book', 'clock', 'vase', 'scissors', 'teddy bear', 'hair drier',
                    'toothbrush'
                ]
            }
            
            # 保存配置
            with open(config_path, 'w', encoding='utf-8') as f:
                yaml.dump(config, f, default_flow_style=False)
            
            print(f"📄 创建COCO配置文件: {config_path}")
            return config
    
    def _get_image_files(self):
        """获取图像文件列表"""
        image_dir = self.data_dir / "images" / self.split
        
        if not image_dir.exists():
            print(f"⚠️  图像目录不存在: {image_dir}")
            print(f"   将在 {image_dir} 创建示例图像...")
            image_dir.mkdir(parents=True, exist_ok=True)
            
            # 创建一些示例图像
            return self._create_sample_images(image_dir, count=20)
        
        # 获取所有图像文件
        image_extensions = ['.jpg', '.jpeg', '.png', '.bmp']
        image_files = []
        
        for ext in image_extensions:
            image_files.extend(list(image_dir.rglob(f"*{ext}")))
        
        # 限制数量用于测试
        image_files = sorted(image_files)
        
        return image_files
    
    def _get_label_files(self):
        """获取标签文件列表"""
        label_dir = self.data_dir / "labels" / self.split
        
        # 如果标签目录不存在，创建示例标签
        if not label_dir.exists():
            label_dir.mkdir(parents=True, exist_ok=True)
            print(f"📝 创建示例标签目录: {label_dir}")
        
        label_files = []
        for img_path in self.image_files:
            label_path = label_dir / f"{img_path.stem}.txt"
            label_files.append(label_path)
            
            # 如果标签文件不存在，创建示例标签
            if not label_path.exists():
                self._create_sample_label(label_path, img_path)
        
        return label_files
    
    def _create_sample_images(self, image_dir, count=20):
        """创建示例图像"""
        image_files = []
        
        for i in range(count):
            # 创建随机大小的图像
            width = random.choice([640, 800, 1024])
            height = random.choice([480, 600, 768])
            
            # 创建带有随机物体的图像
            img = np.zeros((height, width, 3), dtype=np.uint8) + random.randint(100, 200)
            
            # 随机添加一些"车辆"
            for _ in range(random.randint(0, 3)):
                x1 = random.randint(0, width - 100)
                y1 = random.randint(0, height - 80)
                x2 = x1 + random.randint(50, 100)
                y2 = y1 + random.randint(40, 80)
                
                color = (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255))
                cv2.rectangle(img, (x1, y1), (x2, y2), color, -1)
            
            img_path = image_dir / f"coco_sample_{i:04d}.jpg"
            cv2.imwrite(str(img_path), img)
            image_files.append(img_path)
        
        print(f"📷 创建 {len(image_files)} 个示例图像")
        return image_files
    
        num_objects = random.randint(1, 3)  # 改为1-3，确保至少有1个
    
        with open(label_path, 'w') as f:
            for _ in range(num_objects):
                # 随机选择车辆类别
                class_id = random.choice(list(self.vehicle_class_ids.keys()))
            
                # 随机生成归一化边界框
                cx = random.uniform(0.2, 0.8)
                cy = random.uniform(0.2, 0.8)
                w = random.uniform(0.05, 0.2)
                h = random.uniform(0.05, 0.15)
            
                f.write(f"{class_id} {cx:.6f} {cy:.6f} {w:.6f} {h:.6f}\n")
    
        print(f"📝 创建标签: {label_path.name}, 车辆数: {num_objects}")
    
    def __len__(self):
        return len(self.image_files)
    
    def __getitem__(self, idx):
        # 获取图像文件路径
        img_path = self.image_files[idx]
        label_path = self.label_files[idx]
        
        # 加载图像
        try:
            img = cv2.imread(str(img_path))
            if img is None:
                # 创建随机图像
                img = np.zeros((480, 640, 3), dtype=np.uint8) + 128
                print(f"⚠️  无法读取图像: {img_path}")
        except Exception as e:
            print(f"⚠️  图像读取错误: {e}")
            img = np.zeros((480, 640, 3), dtype=np.uint8) + 128
        
        orig_h, orig_w = img.shape[:2]
        
        # 调整图像大小
        img = cv2.resize(img, (self.img_size, self.img_size))
        
        # 转换为PyTorch格式
        img = img[:, :, ::-1].transpose(2, 0, 1)  # BGR to RGB, HWC to CHW
        img = np.ascontiguousarray(img) / 255.0
        
        # 加载标签
        boxes = []
        if label_path.exists():
            try:
                with open(label_path, 'r') as f:
                    for line in f:
                        line = line.strip()
                        if line:
                            parts = line.split()
                            if len(parts) >= 5:
                                class_id = int(parts[0])
                                cx, cy, w, h = map(float, parts[1:5])
                                
                                # 只保留车辆类别
                                if class_id in self.vehicle_class_ids:
                                    boxes.append([class_id, cx, cy, w, h])
            except Exception as e:
                print(f"⚠️  标签读取错误: {e}")
        
        # 转换为Tensor
        img_tensor = torch.from_numpy(img).float()
        
        if boxes:
            boxes_tensor = torch.tensor(boxes, dtype=torch.float32)
        else:
            boxes_tensor = torch.zeros((0, 5), dtype=torch.float32)
        
        return {
            'image': img_tensor,
            'boxes': boxes_tensor,
            'img_path': str(img_path),
            'orig_size': torch.tensor([orig_h, orig_w])
        }
    
    def get_class_name(self, class_id):
        """获取类别名称"""
        if 0 <= class_id < len(self.config['names']):
            return self.config['names'][class_id]
        return f"class_{class_id}"
    
    def is_vehicle_class(self, class_id):
        """检查是否是车辆类别"""
        return class_id in self.vehicle_class_ids

    def _create_sample_label(self, label_path, img_path):
        """创建示例标签文件"""
        # 随机生成一些车辆标注
        import random
        num_objects = random.randint(1, 3)  # 确保至少1个
        
        with open(label_path, 'w') as f:
            for _ in range(num_objects):
                # 随机选择车辆类别
                class_id = random.choice(list(self.vehicle_class_ids.keys()))
                
                # 随机生成归一化边界框
                cx = random.uniform(0.2, 0.8)
                cy = random.uniform(0.2, 0.8)
                w = random.uniform(0.05, 0.2)
                h = random.uniform(0.05, 0.15)
                
                f.write(f"{class_id} {cx:.6f} {cy:.6f} {w:.6f} {h:.6f}\n")
        
        print(f"📝 创建标签: {label_path.name}, 车辆数: {num_objects}")
# 其余代码保持不变...
def create_coco_dataloader(data_dir="data/coco", split="val2014", 
                          batch_size=8, img_size=640, shuffle=False):
    """
    创建COCO数据加载器
    
    返回:
        DataLoader, Dataset
    """
    dataset = RealCOCODataset(
        data_dir=data_dir,
        split=split,
        img_size=img_size
    )
    
    def collate_fn(batch):
        images = []
        boxes_list = []
        img_paths = []
        orig_sizes = []
        
        for item in batch:
            images.append(item['image'])
            boxes_list.append(item['boxes'])
            img_paths.append(item['img_path'])
            orig_sizes.append(item['orig_size'])
        
        images = torch.stack(images, 0)
        
        return {
            'image': images,
            'boxes': boxes_list,
            'img_path': img_paths,
            'orig_size': torch.stack(orig_sizes, 0)
        }
    
    dataloader = DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=shuffle,
        collate_fn=collate_fn,
        num_workers=0
    )
    
    return dataloader, dataset

def test_coco_dataset():
    """测试COCO数据集"""
    print("🧪 测试真实COCO数据集...")
    
    try:
        dataloader, dataset = create_coco_dataloader(
            data_dir="data/coco",
            split="val2014",
            batch_size=2,
            img_size=640
        )
        
        print(f"✅ 数据集大小: {len(dataset)}")
        
        # 获取一个批次
        batch = next(iter(dataloader))
        print(f"✅ 批次图像形状: {batch['image'].shape}")
        
        # 统计车辆数量
        vehicle_count = 0
        for boxes in batch['boxes']:
            for box in boxes:
                if len(box) >= 1 and dataset.is_vehicle_class(int(box[0])):
                    vehicle_count += 1
        
        print(f"✅ 车辆检测数: {vehicle_count}")
        
        return True
        
    except Exception as e:
        print(f"❌ 测试失败: {e}")
        import traceback
        traceback.print_exc()
        return False

# ============================================================================
# 兼容性别名
# ============================================================================

# 为了向后兼容，将 RealCOCODataset 也导出为 YOLOCOCOLoader
# 这样旧的导入代码不需要修改
YOLOCOCOLoader = RealCOCODataset

# 如果原来有 get_vehicle_images 方法，需要添加到新类中
def get_vehicle_images(self, split="val2014", max_samples=20):
    """兼容性方法：获取包含车辆的图像"""
    print(f"⚠️  使用兼容性方法，建议使用 create_coco_dataloader 替代")
    
    # 创建数据加载器获取数据
    from .coco_loader import create_coco_dataloader
    dataloader, dataset = create_coco_dataloader(
        split=split.replace("2014", "") if "2014" in split else split,
        batch_size=1,
        img_size=640,
        shuffle=True
    )
    
    vehicle_images = []
    for i, batch in enumerate(dataloader):
        if i >= max_samples:
            break
        
        image_path = batch['img_path'][0]
        boxes = batch['boxes'][0]
        
        # 统计车辆数量
        vehicle_count = 0
        vehicle_annotations = []
        
        for box in boxes:
            if len(box) >= 5:
                class_id = int(box[0])
                # 检查是否是车辆类别
                if class_id in [2, 3, 5, 7]:  # car, motorcycle, bus, truck
                    vehicle_count += 1
                    
                    cx, cy, w, h = box[1:5].tolist()
                    orig_h, orig_w = batch['orig_size'][0].tolist()
                    
                    # 转换为像素坐标
                    x_center = cx * orig_w
                    y_center = cy * orig_h
                    width = w * orig_w
                    height = h * orig_h
                    
                    x1 = x_center - width / 2
                    y1 = y_center - height / 2
                    x2 = x_center + width / 2
                    y2 = y_center + height / 2
                    
                    vehicle_annotations.append({
                        "class_id": class_id,
                        "class_name": dataset.get_class_name(class_id),
                        "bbox": [float(x1), float(y1), float(x2), float(y2)],
                        "bbox_normalized": [float(cx), float(cy), float(w), float(h)],
                        "area": float(width * height)
                    })
        
        vehicle_images.append({
            "image_path": image_path,
            "num_vehicles": vehicle_count,
            "vehicle_annotations": vehicle_annotations,
            "width": int(orig_w),
            "height": int(orig_h),
            "split": split
        })
    
    return vehicle_images

# 将兼容性方法添加到类中
RealCOCODataset.get_vehicle_images = get_vehicle_images
YOLOCOCOLoader.get_vehicle_images = get_vehicle_images

if __name__ == "__main__":
    test_coco_dataset()