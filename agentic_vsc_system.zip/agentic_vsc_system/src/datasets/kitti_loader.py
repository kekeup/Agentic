import cv2
import numpy as np
from pathlib import Path
import yaml
import torch
from torch.utils.data import Dataset, DataLoader
import random
import os
from typing import Dict, Any, List, Tuple, Optional
from datetime import datetime

class KITTIDataset(Dataset):
    """KITTI自动驾驶数据集 - 兼容YOLO格式"""
    
    def __init__(self, data_dir="data/kitti", split="train", img_size=640, augment=False):
        """
        参数:
            data_dir: 数据目录路径
            split: 'train' 或 'val'
            img_size: 图像调整大小
            augment: 是否数据增强
        """
        self.data_dir = Path(data_dir)
        self.split = split
        self.img_size = img_size
        self.augment = augment and split == 'train'
        
        # 加载配置
        self.config = self._load_config()
        
        # 获取文件列表
        self.image_files = self._get_image_files()
        self.label_files = self._get_label_files()
        
        # 验证文件对应关系
        self._validate_files()
        
        print(f"✅ KITTI {split} 数据集: {len(self.image_files)} 张图像")
        print(f"   类别数: {self.config.get('nc', '未知')}")
        
        # 显示类别信息
        names = self.config.get('names', {})
        if isinstance(names, dict):
            names_list = list(names.values())
            print(f"   类别: {', '.join(names_list[:4])}...")
        elif isinstance(names, list):
            print(f"   类别: {', '.join(names[:4])}...")
    
    def _get_image_files(self) -> List[Path]:
        """获取图像文件列表"""
        image_files = []
        
        # 可能的图像目录结构
        possible_paths = [
            self.data_dir / "images" / self.split,
            self.data_dir / self.split / "images",
            self.data_dir / "images",
            self.data_dir
        ]
        
        # 支持的图像格式
        image_extensions = ['.png', '.jpg', '.jpeg', '.bmp', '.tiff']
        
        for base_path in possible_paths:
            if base_path.exists():
                print(f"🔍 搜索图像目录: {base_path}")
                
                # 递归查找所有图像文件
                for ext in image_extensions:
                    files = list(base_path.rglob(f"*{ext}"))
                    image_files.extend([f for f in files if f.is_file()])
                
                if image_files:
                    print(f"   找到 {len(image_files)} 张图像")
                    break
        
        if not image_files:
            # 如果没有找到图像，创建演示数据
            print(f"⚠️  在 {self.data_dir} 中未找到图像文件，创建演示数据")
            image_files = self._create_demo_images()
        
        # 按文件名排序以确保一致性
        image_files.sort(key=lambda x: x.name)
        
        return image_files  # 限制样本数量
    
    def _get_label_files(self) -> List[Optional[Path]]:
        """获取标签文件列表"""
        label_files = []
        
        for img_path in self.image_files:
            # 尝试多个可能的标签目录
            possible_label_dirs = [
                self.data_dir / "labels" / self.split,
                self.data_dir / self.split / "labels", 
                self.data_dir / "labels",
                img_path.parent.parent / "labels" / self.split,
                img_path.parent.parent / self.split / "labels",
                self.data_dir / "demo_labels"  # 演示标签目录
            ]
            
            label_found = False
            for label_dir in possible_label_dirs:
                if label_dir.exists():
                    label_path = label_dir / f"{img_path.stem}.txt"
                    if label_path.exists():
                        label_files.append(label_path)
                        label_found = True
                        break
            
            if not label_found:
                # 如果没有找到标签文件，创建一个空标签
                label_files.append(None)
        
        return label_files
    
    def _load_config(self) -> Dict[str, Any]:
        """加载kitti.yaml配置文件"""
        config_path = self.data_dir / "kitti.yaml"
        
        if config_path.exists():
            with open(config_path, 'r', encoding='utf-8') as f:
                config = yaml.safe_load(f)
        else:
            # 默认配置
            config = {
                'path': str(self.data_dir),
                'train': 'images/train',
                'val': 'images/val',
                'names': {
                    0: 'car',
                    1: 'van', 
                    2: 'truck',
                    3: 'pedestrian',
                    4: 'Person_sitting',
                    5: 'cyclist',
                    6: 'tram',
                    7: 'misc'
                },
                'nc': 8
            }
            
            # 保存默认配置
            with open(config_path, 'w', encoding='utf-8') as f:
                yaml.dump(config, f, default_flow_style=False)
            
            print(f"📄 创建默认配置文件: {config_path}")
        
        # 确保有必要的字段
        if 'nc' not in config:
            names = config.get('names', {})
            if isinstance(names, dict):
                config['nc'] = len(names)
            elif isinstance(names, list):
                config['nc'] = len(names)
            else:
                config['nc'] = 8
        
        return config
    
    def _create_demo_images(self) -> List[Path]:
        """创建演示图像用于测试"""
        demo_dir = self.data_dir / "demo_images"
        demo_dir.mkdir(exist_ok=True)
        
        demo_files = []
        for i in range(50):  # 创建50个演示图像
            # 创建随机图像（模拟道路场景）
            height, width = 375, 1242  # KITTI标准尺寸
            img = np.zeros((height, width, 3), dtype=np.uint8)
            
            # 添加道路背景（灰色）
            img[:, :] = [128, 128, 128]
            
            # 添加随机车辆（矩形）
            for _ in range(random.randint(1, 5)):
                x1 = random.randint(0, width - 200)
                y1 = random.randint(0, height - 100)
                x2 = x1 + random.randint(50, 200)
                y2 = y1 + random.randint(30, 100)
                
                # 车辆颜色（随机）
                color = (random.randint(0, 255), 
                        random.randint(0, 255), 
                        random.randint(0, 255))
                cv2.rectangle(img, (x1, y1), (x2, y2), color, -1)
            
            img_path = demo_dir / f"demo_{i:04d}.jpg"
            cv2.imwrite(str(img_path), img)
            
            # 创建对应的标签文件
            label_dir = self.data_dir / "demo_labels"
            label_dir.mkdir(exist_ok=True)
            label_path = label_dir / f"demo_{i:04d}.txt"
            
            with open(label_path, 'w') as f:
                # 创建车辆标注
                for j in range(random.randint(1, 3)):
                    cls_id = random.randint(0, 7)  # KITTI类别
                    cx = random.uniform(0.1, 0.9)
                    cy = random.uniform(0.1, 0.9)
                    w = random.uniform(0.05, 0.2)
                    h = random.uniform(0.05, 0.15)
                    f.write(f"{cls_id} {cx:.6f} {cy:.6f} {w:.6f} {h:.6f}\n")
            
            demo_files.append(img_path)
        
        print(f"📁 创建 {len(demo_files)} 个演示图像")
        return demo_files
    
    def _validate_files(self):
        """验证图像和标注文件对应"""
        missing_count = 0
        for i, (img_file, label_file) in enumerate(zip(self.image_files, self.label_files)):
            if label_file is None:
                missing_count += 1
                if missing_count <= 3:  # 只显示前3个缺失
                    print(f"⚠️  警告: 图像 {img_file.name} 没有对应的标注文件")
        
        if missing_count > 0:
            print(f"⚠️  总计: 发现 {missing_count} 个图像没有对应的标注文件")
    
    def __len__(self) -> int:
        return len(self.image_files)
    
    def __getitem__(self, idx: int) -> Dict[str, Any]:
        # 获取文件路径
        img_path = self.image_files[idx]
        label_path = self.label_files[idx]
        
        # 安全加载图像
        try:
            img = cv2.imread(str(img_path))
            if img is None:
                print(f"⚠️  无法读取图像: {img_path}")
                # 创建随机图像作为后备
                img = np.zeros((375, 1242, 3), dtype=np.uint8) + 128
        except Exception as e:
            print(f"⚠️  加载图像失败 {img_path.name}: {e}")
            img = np.zeros((375, 1242, 3), dtype=np.uint8) + 128
        
        orig_h, orig_w = img.shape[:2]
        
        # 数据增强（训练时）
        if self.augment:
            img = self._augment_image(img)
        
        # 调整大小
        img = cv2.resize(img, (self.img_size, self.img_size))
        
        # 转换为PyTorch格式: HWC -> CHW, BGR -> RGB, 归一化
        img = img[:, :, ::-1].transpose(2, 0, 1)  # BGR to RGB, HWC to CHW
        img = np.ascontiguousarray(img) / 255.0  # 归一化到 [0, 1]
        
        # 加载标注
        boxes = []
        if label_path is not None and label_path.exists():
            try:
                with open(label_path, 'r') as f:
                    for line in f:
                        line = line.strip()
                        if line:
                            parts = line.split()
                            if len(parts) >= 5:
                                cls_id = int(parts[0])
                                cx, cy, w, h = map(float, parts[1:5])
                                boxes.append([cls_id, cx, cy, w, h])
            except Exception as e:
                print(f"⚠️  加载标注失败 {label_path.name}: {e}")
        
        # 转换为Tensor
        img_tensor = torch.from_numpy(img).float()
        
        if boxes:
            boxes_tensor = torch.tensor(boxes, dtype=torch.float32)
        else:
            boxes_tensor = torch.zeros((0, 5), dtype=torch.float32)
        
        return {
            'image': img_tensor,
            'boxes': boxes_tensor,
            'img_path': str(img_path),
            'orig_size': torch.tensor([orig_h, orig_w]),
            'label_path': str(label_path) if label_path else None
        }
    
    def _augment_image(self, img: np.ndarray) -> np.ndarray:
        """简单的数据增强"""
        # 随机水平翻转
        if random.random() > 0.5:
            img = cv2.flip(img, 1)
        
        # 随机亮度调整
        if random.random() > 0.5:
            hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
            hsv[:, :, 2] = hsv[:, :, 2] * random.uniform(0.8, 1.2)
            hsv[:, :, 2] = np.clip(hsv[:, :, 2], 0, 255)
            img = cv2.cvtColor(hsv, cv2.COLOR_HSV2BGR)
        
        # 随机对比度调整
        if random.random() > 0.5:
            alpha = random.uniform(0.8, 1.2)
            img = cv2.convertScaleAbs(img, alpha=alpha, beta=0)
        
        return img
    
    def get_class_name(self, class_id: int) -> str:
        """获取类别名称"""
        names = self.config.get('names', {})
        
        if isinstance(names, dict):
            # 字典格式: {0: 'car', 1: 'van', ...}
            return names.get(str(class_id), f'class_{class_id}')
        elif isinstance(names, list) and 0 <= class_id < len(names):
            # 列表格式: ['car', 'van', ...]
            return names[class_id]
        else:
            # 默认类别名称
            default_names = {
                0: 'car', 1: 'van', 2: 'truck', 3: 'pedestrian',
                4: 'Person_sitting', 5: 'cyclist', 6: 'tram', 7: 'misc'
            }
            return default_names.get(class_id, f'class_{class_id}')
    
    def get_classes(self) -> List[str]:
        """获取所有类别名称列表"""
        names = self.config.get('names', {})
        
        if isinstance(names, dict):
            # 字典转列表，按键排序
            sorted_keys = sorted([int(k) for k in names.keys() if str(k).isdigit()])
            return [names[str(i)] for i in sorted_keys if str(i) in names]
        elif isinstance(names, list):
            return names
        else:
            return ['car', 'van', 'truck', 'pedestrian', 
                   'Person_sitting', 'cyclist', 'tram', 'misc']
    
    def visualize_sample(self, idx: int, save_path: Optional[str] = None) -> Optional[np.ndarray]:
        """可视化一个样本"""
        try:
            import matplotlib.pyplot as plt
            
            sample = self[idx]
            img = sample['image'].numpy().transpose(1, 2, 0)  # CHW -> HWC
            img = (img * 255).astype(np.uint8)
            boxes = sample['boxes'].numpy()
            
            # 绘制图像
            fig, ax = plt.subplots(1, figsize=(10, 10))
            ax.imshow(img)
            
            # 绘制边界框
            for box in boxes:
                cls_id, cx, cy, w, h = box
                # 转换为像素坐标
                x1 = (cx - w/2) * self.img_size
                y1 = (cy - h/2) * self.img_size
                x2 = (cx + w/2) * self.img_size
                y2 = (cy + h/2) * self.img_size
                
                # 绘制矩形
                rect = plt.Rectangle((x1, y1), x2-x1, y2-y1,
                                   linewidth=2, edgecolor='red', facecolor='none')
                ax.add_patch(rect)
                
                # 添加类别标签
                class_name = self.get_class_name(int(cls_id))
                ax.text(x1, y1-5, class_name, color='red', fontsize=12,
                       bbox=dict(facecolor='white', alpha=0.7, edgecolor='none'))
            
            ax.axis('off')
            ax.set_title(f"KITTI样本 {idx}: {len(boxes)} 个目标")
            
            if save_path:
                plt.savefig(save_path, bbox_inches='tight', dpi=150)
                print(f"📸 图像保存到: {save_path}")
            
            plt.show()
            return img
            
        except ImportError:
            print("⚠️  matplotlib未安装，跳过可视化")
            return None
        except Exception as e:
            print(f"⚠️  可视化失败: {e}")
            return None
    
    def get_sample_info(self, idx: int) -> Dict[str, Any]:
        """获取样本详细信息"""
        sample = self[idx]
        
        return {
            'image_path': sample['img_path'],
            'label_path': sample['label_path'],
            'image_size': sample['orig_size'].tolist(),
            'num_boxes': len(sample['boxes']),
            'classes': [self.get_class_name(int(box[0])) for box in sample['boxes'].numpy()],
            'dataset_split': self.split,
            'dataset_size': len(self)
        }


def collate_fn(batch: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    自定义collate函数
    
    参数:
        batch: 批次数据列表
        
    返回:
        整理后的批次数据
    """
    images = []
    boxes_list = []
    img_paths = []
    orig_sizes = []
    
    for item in batch:
        images.append(item['image'])
        boxes_list.append(item['boxes'])
        img_paths.append(item['img_path'])
        orig_sizes.append(item['orig_size'])
    
    # 堆叠图像
    images = torch.stack(images, 0)
    
    return {
        'image': images,
        'boxes': boxes_list,
        'img_path': img_paths,
        'orig_size': torch.stack(orig_sizes, 0)
    }


def create_kitti_dataloader(
    data_dir: str = "data/kitti",
    split: str = "train",
    batch_size: int = 8,
    img_size: int = 640,
    augment: bool = False,
    shuffle: bool = True,
    num_workers: int = 0,
    pin_memory: bool = True
) -> Tuple[DataLoader, KITTIDataset]:
    """
    创建KITTI数据加载器
    
    参数:
        data_dir: 数据目录路径
        split: 'train' 或 'val'
        batch_size: 批次大小
        img_size: 图像大小
        augment: 是否数据增强
        shuffle: 是否打乱数据
        num_workers: 工作进程数
        pin_memory: 是否固定内存
        
    返回:
        DataLoader对象和Dataset对象
    """
    # 创建数据集
    dataset = KITTIDataset(
        data_dir=data_dir,
        split=split,
        img_size=img_size,
        augment=augment
    )
    
    # 创建数据加载器
    dataloader = DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=shuffle,
        num_workers=num_workers,
        collate_fn=collate_fn,
        pin_memory=pin_memory
    )
    
    return dataloader, dataset


def create_simple_dataloader(
    batch_size: int = 4,
    img_size: int = 640,
    num_batches: int = 10
) -> DataLoader:
    """
    创建简化数据加载器（用于测试）
    
    参数:
        batch_size: 批次大小
        img_size: 图像大小
        num_batches: 批次数量
        
    返回:
        DataLoader对象
    """
    class SimpleDataset(Dataset):
        def __len__(self):
            return batch_size * num_batches
        
        def __getitem__(self, idx):
            # 创建随机图像
            img = torch.randn(3, img_size, img_size).float()
            
            # 创建随机标注
            num_boxes = random.randint(0, 5)
            boxes = torch.zeros(num_boxes, 5)
            for i in range(num_boxes):
                boxes[i] = torch.tensor([
                    random.randint(0, 7),  # class_id
                    random.random(),  # cx
                    random.random(),  # cy
                    random.random() * 0.3,  # w
                    random.random() * 0.3  # h
                ])
            
            return {
                'image': img,
                'boxes': boxes,
                'img_path': f'synthetic_{idx}.jpg',
                'orig_size': torch.tensor([img_size, img_size])
            }
    
    dataset = SimpleDataset()
    
    return DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=True,
        collate_fn=collate_fn,
        num_workers=0
    )


def test_kitti_dataset():
    """测试KITTI数据集"""
    print("🧪 测试KITTI数据集...")
    print("=" * 60)
    
    try:
        # 测试数据集创建
        print("📊 创建数据集...")
        dataset = KITTIDataset(split="val", img_size=640)
        
        print(f"✅ 数据集创建成功")
        print(f"   数据集大小: {len(dataset)}")
        print(f"   类别数: {dataset.config.get('nc', '未知')}")
        print(f"   类别列表: {dataset.get_classes()}")
        
        # 测试数据加载
        print("\n📥 测试数据加载...")
        if len(dataset) > 0:
            sample = dataset[0]
            print(f"   图像形状: {sample['image'].shape}")
            print(f"   标注数量: {len(sample['boxes'])}")
            print(f"   图像路径: {sample['img_path']}")
            
            # 显示类别
            if len(sample['boxes']) > 0:
                print(f"   检测类别: {[dataset.get_class_name(int(box[0])) for box in sample['boxes'].numpy()[:3]]}")
        
        # 测试数据加载器
        print("\n📦 测试数据加载器...")
        dataloader, _ = create_kitti_dataloader(
            batch_size=2,
            shuffle=True
        )
        
        # 获取一个批次
        batch = next(iter(dataloader))
        print(f"   批次图像形状: {batch['image'].shape}")
        print(f"   批次标注数量: {len(batch['boxes'])}")
        
        # 测试可视化
        print("\n👀 测试可视化...")
        os.makedirs("data/visualization", exist_ok=True)
        dataset.visualize_sample(0, "data/visualization/kitti_sample.png")
        
        print("\n✅ KITTI数据集测试完成!")
        return True
        
    except Exception as e:
        print(f"❌ KITTI数据集测试失败: {e}")
        import traceback
        traceback.print_exc()
        return False


def get_dataset_statistics(data_dir: str = "data/kitti") -> Dict[str, Any]:
    """
    获取数据集统计信息
    
    参数:
        data_dir: 数据目录
        
    返回:
        统计信息字典
    """
    stats = {
        'dataset': 'KITTI',
        'timestamp': datetime.now().isoformat()
    }
    
    try:
        # 训练集统计
        train_dataset = KITTIDataset(data_dir=data_dir, split="train")
        stats['train'] = {
            'num_samples': len(train_dataset),
            'num_classes': train_dataset.config.get('nc', 0),
            'classes': train_dataset.get_classes()
        }
        
        # 验证集统计
        val_dataset = KITTIDataset(data_dir=data_dir, split="val")
        stats['val'] = {
            'num_samples': len(val_dataset),
            'num_classes': val_dataset.config.get('nc', 0)
        }
        
        # 计算标注统计
        total_boxes = 0
        class_counts = {}
        
        for i in range(min(100, len(train_dataset))):  # 只统计前100个样本
            sample = train_dataset[i]
            boxes = sample['boxes'].numpy()
            total_boxes += len(boxes)
            
            for box in boxes:
                cls_id = int(box[0])
                class_counts[cls_id] = class_counts.get(cls_id, 0) + 1
        
        stats['annotations'] = {
            'total_boxes_sampled': total_boxes,
            'average_boxes_per_image': total_boxes / 100 if total_boxes > 0 else 0,
            'class_distribution': {
                train_dataset.get_class_name(cls_id): count 
                for cls_id, count in class_counts.items()
            }
        }
        
    except Exception as e:
        stats['error'] = str(e)
    
    return stats


if __name__ == "__main__":
    test_kitti_dataset()