import cv2
import numpy as np
from pathlib import Path
import yaml
import torch
from torch.utils.data import Dataset, DataLoader
import random
import os
from typing import Dict, Any, List, Tuple, Optional
from datetime import datetime

class KITTIDataset(Dataset):
    def __init__(self, data_dir="data/kitti", split="train", img_size=640, augment=False):
        self.data_dir = Path(data_dir)
        self.split = split
        self.img_size = img_size
        self.augment = augment and split == 'train'
        
        # Load configuration
        self.config = self._load_config()
        
        # Get file list
        self.image_files = self._get_image_files()
        self.label_files = self._get_label_files()
        
        # Validate file correspondence
        self._validate_files()
        
        print(f"✅ KITTI {split} dataset: {len(self.image_files)} images")
        print(f"   Number of classes: {self.config.get('nc', 'unknown')}")
        
        # Display class information
        names = self.config.get('names', {})
        if isinstance(names, dict):
            names_list = list(names.values())
            print(f"   Classes: {', '.join(names_list[:4])}...")
        elif isinstance(names, list):
            print(f"   Classes: {', '.join(names[:4])}...")
    
    def _get_image_files(self) -> List[Path]:
        """Get list of image files"""
        image_files = []
        
        # Possible image directory structures
        possible_paths = [
            self.data_dir / "images" / self.split,
            self.data_dir / self.split / "images",
            self.data_dir / "images",
            self.data_dir
        ]
        
        # Supported image formats
        image_extensions = ['.png', '.jpg', '.jpeg', '.bmp', '.tiff']
        
        for base_path in possible_paths:
            if base_path.exists():
                print(f"🔍 Searching image directory: {base_path}")
                
                # Recursively find all image files
                for ext in image_extensions:
                    files = list(base_path.rglob(f"*{ext}"))
                    image_files.extend([f for f in files if f.is_file()])
                
                if image_files:
                    print(f"   Found {len(image_files)} images")
                    break
        
        if not image_files:
            # If no images found, create demo data
            print(f"⚠️  No image files found in {self.data_dir}, creating demo data")
            image_files = self._create_demo_images()
        
        # Sort by filename for consistency
        image_files.sort(key=lambda x: x.name)
        
        return image_files  # Limit sample count
    
    def _get_label_files(self) -> List[Optional[Path]]:
        """Get list of label files"""
        label_files = []
        
        for img_path in self.image_files:
            # Try multiple possible label directories
            possible_label_dirs = [
                self.data_dir / "labels" / self.split,
                self.data_dir / self.split / "labels", 
                self.data_dir / "labels",
                img_path.parent.parent / "labels" / self.split,
                img_path.parent.parent / self.split / "labels",
                self.data_dir / "demo_labels"  # Demo label directory
            ]
            
            label_found = False
            for label_dir in possible_label_dirs:
                if label_dir.exists():
                    label_path = label_dir / f"{img_path.stem}.txt"
                    if label_path.exists():
                        label_files.append(label_path)
                        label_found = True
                        break
            
            if not label_found:
                # If no label file found, create an empty label
                label_files.append(None)
        
        return label_files
    
    def _load_config(self) -> Dict[str, Any]:
        """Load kitti.yaml configuration file"""
        config_path = self.data_dir / "kitti.yaml"
        
        if config_path.exists():
            with open(config_path, 'r', encoding='utf-8') as f:
                config = yaml.safe_load(f)
        else:
            # Default configuration
            config = {
                'path': str(self.data_dir),
                'train': 'images/train',
                'val': 'images/val',
                'names': {
                    0: 'car',
                    1: 'van', 
                    2: 'truck',
                    3: 'pedestrian',
                    4: 'Person_sitting',
                    5: 'cyclist',
                    6: 'tram',
                    7: 'misc'
                },
                'nc': 8
            }
            
            # Save default configuration
            with open(config_path, 'w', encoding='utf-8') as f:
                yaml.dump(config, f, default_flow_style=False)
            
            print(f"📄 Created default configuration file: {config_path}")
        
        # Ensure necessary fields exist
        if 'nc' not in config:
            names = config.get('names', {})
            if isinstance(names, dict):
                config['nc'] = len(names)
            elif isinstance(names, list):
                config['nc'] = len(names)
            else:
                config['nc'] = 8
        
        return config
    
    def _create_demo_images(self) -> List[Path]:
        """Create demo images for testing"""
        demo_dir = self.data_dir / "demo_images"
        demo_dir.mkdir(exist_ok=True)
        
        demo_files = []
        for i in range(50):  # Create 50 demo images
            # Create random image (simulating road scenes)
            height, width = 375, 1242  # KITTI standard size
            img = np.zeros((height, width, 3), dtype=np.uint8)
            
            # Add road background (gray)
            img[:, :] = [128, 128, 128]
            
            # Add random vehicles (rectangles)
            for _ in range(random.randint(1, 5)):
                x1 = random.randint(0, width - 200)
                y1 = random.randint(0, height - 100)
                x2 = x1 + random.randint(50, 200)
                y2 = y1 + random.randint(30, 100)
                
                # Vehicle color (random)
                color = (random.randint(0, 255), 
                        random.randint(0, 255), 
                        random.randint(0, 255))
                cv2.rectangle(img, (x1, y1), (x2, y2), color, -1)
            
            img_path = demo_dir / f"demo_{i:04d}.jpg"
            cv2.imwrite(str(img_path), img)
            
            # Create corresponding label file
            label_dir = self.data_dir / "demo_labels"
            label_dir.mkdir(exist_ok=True)
            label_path = label_dir / f"demo_{i:04d}.txt"
            
            with open(label_path, 'w') as f:
                # Create vehicle annotations
                for j in range(random.randint(1, 3)):
                    cls_id = random.randint(0, 7)  # KITTI classes
                    cx = random.uniform(0.1, 0.9)
                    cy = random.uniform(0.1, 0.9)
                    w = random.uniform(0.05, 0.2)
                    h = random.uniform(0.05, 0.15)
                    f.write(f"{cls_id} {cx:.6f} {cy:.6f} {w:.6f} {h:.6f}\n")
            
            demo_files.append(img_path)
        
        print(f"📁 Created {len(demo_files)} demo images")
        return demo_files
    
    def _validate_files(self):
        """Validate correspondence between images and annotation files"""
        missing_count = 0
        for i, (img_file, label_file) in enumerate(zip(self.image_files, self.label_files)):
            if label_file is None:
                missing_count += 1
                if missing_count <= 3:  # Only show first 3 missing
                    print(f"⚠️  Warning: Image {img_file.name} has no corresponding annotation file")
        
        if missing_count > 0:
            print(f"⚠️  Total: Found {missing_count} images without corresponding annotation files")
    
    def __len__(self) -> int:
        return len(self.image_files)
    
    def __getitem__(self, idx: int) -> Dict[str, Any]:
        # Get file paths
        img_path = self.image_files[idx]
        label_path = self.label_files[idx]
        
        # Safely load image
        try:
            img = cv2.imread(str(img_path))
            if img is None:
                print(f"⚠️  Unable to read image: {img_path}")
                # Create random image as fallback
                img = np.zeros((375, 1242, 3), dtype=np.uint8) + 128
        except Exception as e:
            print(f"⚠️  Failed to load image {img_path.name}: {e}")
            img = np.zeros((375, 1242, 3), dtype=np.uint8) + 128
        
        orig_h, orig_w = img.shape[:2]
        
        # Data augmentation (during training)
        if self.augment:
            img = self._augment_image(img)
        
        # Resize
        img = cv2.resize(img, (self.img_size, self.img_size))
        
        # Convert to PyTorch format: HWC -> CHW, BGR -> RGB, normalize
        img = img[:, :, ::-1].transpose(2, 0, 1)  # BGR to RGB, HWC to CHW
        img = np.ascontiguousarray(img) / 255.0  # Normalize to [0, 1]
        
        # Load annotations
        boxes = []
        if label_path is not None and label_path.exists():
            try:
                with open(label_path, 'r') as f:
                    for line in f:
                        line = line.strip()
                        if line:
                            parts = line.split()
                            if len(parts) >= 5:
                                cls_id = int(parts[0])
                                cx, cy, w, h = map(float, parts[1:5])
                                boxes.append([cls_id, cx, cy, w, h])
            except Exception as e:
                print(f"⚠️  Failed to load annotations {label_path.name}: {e}")
        
        # Convert to Tensor
        img_tensor = torch.from_numpy(img).float()
        
        if boxes:
            boxes_tensor = torch.tensor(boxes, dtype=torch.float32)
        else:
            boxes_tensor = torch.zeros((0, 5), dtype=torch.float32)
        
        return {
            'image': img_tensor,
            'boxes': boxes_tensor,
            'img_path': str(img_path),
            'orig_size': torch.tensor([orig_h, orig_w]),
            'label_path': str(label_path) if label_path else None
        }
    
    def _augment_image(self, img: np.ndarray) -> np.ndarray:
        """Simple data augmentation"""
        # Random horizontal flip
        if random.random() > 0.5:
            img = cv2.flip(img, 1)
        
        # Random brightness adjustment
        if random.random() > 0.5:
            hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
            hsv[:, :, 2] = hsv[:, :, 2] * random.uniform(0.8, 1.2)
            hsv[:, :, 2] = np.clip(hsv[:, :, 2], 0, 255)
            img = cv2.cvtColor(hsv, cv2.COLOR_HSV2BGR)
        
        # Random contrast adjustment
        if random.random() > 0.5:
            alpha = random.uniform(0.8, 1.2)
            img = cv2.convertScaleAbs(img, alpha=alpha, beta=0)
        
        return img
    
    def get_class_name(self, class_id: int) -> str:
        """Get class name"""
        names = self.config.get('names', {})
        
        if isinstance(names, dict):
            # Dictionary format: {0: 'car', 1: 'van', ...}
            return names.get(str(class_id), f'class_{class_id}')
        elif isinstance(names, list) and 0 <= class_id < len(names):
            # List format: ['car', 'van', ...]
            return names[class_id]
        else:
            # Default class names
            default_names = {
                0: 'car', 1: 'van', 2: 'truck', 3: 'pedestrian',
                4: 'Person_sitting', 5: 'cyclist', 6: 'tram', 7: 'misc'
            }
            return default_names.get(class_id, f'class_{class_id}')
    
    def get_classes(self) -> List[str]:
        """Get all class names list"""
        names = self.config.get('names', {})
        
        if isinstance(names, dict):
            # Convert dictionary to list, sorted by keys
            sorted_keys = sorted([int(k) for k in names.keys() if str(k).isdigit()])
            return [names[str(i)] for i in sorted_keys if str(i) in names]
        elif isinstance(names, list):
            return names
        else:
            return ['car', 'van', 'truck', 'pedestrian', 
                   'Person_sitting', 'cyclist', 'tram', 'misc']
    
    def visualize_sample(self, idx: int, save_path: Optional[str] = None) -> Optional[np.ndarray]:
        """Visualize a sample"""
        try:
            import matplotlib.pyplot as plt
            
            sample = self[idx]
            img = sample['image'].numpy().transpose(1, 2, 0)  # CHW -> HWC
            img = (img * 255).astype(np.uint8)
            boxes = sample['boxes'].numpy()
            
            # Draw image
            fig, ax = plt.subplots(1, figsize=(10, 10))
            ax.imshow(img)
            
            # Draw bounding boxes
            for box in boxes:
                cls_id, cx, cy, w, h = box
                # Convert to pixel coordinates
                x1 = (cx - w/2) * self.img_size
                y1 = (cy - h/2) * self.img_size
                x2 = (cx + w/2) * self.img_size
                y2 = (cy + h/2) * self.img_size
                
                # Draw rectangle
                rect = plt.Rectangle((x1, y1), x2-x1, y2-y1,
                                   linewidth=2, edgecolor='red', facecolor='none')
                ax.add_patch(rect)
                
                # Add class label
                class_name = self.get_class_name(int(cls_id))
                ax.text(x1, y1-5, class_name, color='red', fontsize=12,
                       bbox=dict(facecolor='white', alpha=0.7, edgecolor='none'))
            
            ax.axis('off')
            ax.set_title(f"KITTI sample {idx}: {len(boxes)} objects")
            
            if save_path:
                plt.savefig(save_path, bbox_inches='tight', dpi=150)
                print(f"📸 Image saved to: {save_path}")
            
            plt.show()
            return img
            
        except ImportError:
            print("⚠️  matplotlib not installed, skipping visualization")
            return None
        except Exception as e:
            print(f"⚠️  Visualization failed: {e}")
            return None
    
    def get_sample_info(self, idx: int) -> Dict[str, Any]:
        """Get sample detailed information"""
        sample = self[idx]
        
        return {
            'image_path': sample['img_path'],
            'label_path': sample['label_path'],
            'image_size': sample['orig_size'].tolist(),
            'num_boxes': len(sample['boxes']),
            'classes': [self.get_class_name(int(box[0])) for box in sample['boxes'].numpy()],
            'dataset_split': self.split,
            'dataset_size': len(self)
        }


def collate_fn(batch: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Custom collate function
    
    Parameters:
        batch: List of batch data
        
    Returns:
        Collated batch data
    """
    images = []
    boxes_list = []
    img_paths = []
    orig_sizes = []
    
    for item in batch:
        images.append(item['image'])
        boxes_list.append(item['boxes'])
        img_paths.append(item['img_path'])
        orig_sizes.append(item['orig_size'])
    
    # Stack images
    images = torch.stack(images, 0)
    
    return {
        'image': images,
        'boxes': boxes_list,
        'img_path': img_paths,
        'orig_size': torch.stack(orig_sizes, 0)
    }


def create_kitti_dataloader(
    data_dir: str = "data/kitti",
    split: str = "train",
    batch_size: int = 8,
    img_size: int = 640,
    augment: bool = False,
    shuffle: bool = True,
    num_workers: int = 0,
    pin_memory: bool = True
) -> Tuple[DataLoader, KITTIDataset]:
    """
    Create KITTI data loader
    
    Parameters:
        data_dir: Data directory path
        split: 'train' or 'val'
        batch_size: Batch size
        img_size: Image size
        augment: Whether to use data augmentation
        shuffle: Whether to shuffle data
        num_workers: Number of worker processes
        pin_memory: Whether to pin memory
        
    Returns:
        DataLoader object and Dataset object
    """
    # Create dataset
    dataset = KITTIDataset(
        data_dir=data_dir,
        split=split,
        img_size=img_size,
        augment=augment
    )
    
    # Create data loader
    dataloader = DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=shuffle,
        num_workers=num_workers,
        collate_fn=collate_fn,
        pin_memory=pin_memory
    )
    
    return dataloader, dataset


def create_simple_dataloader(
    batch_size: int = 4,
    img_size: int = 640,
    num_batches: int = 10
) -> DataLoader:
    """
    Create simplified data loader (for testing)
    
    Parameters:
        batch_size: Batch size
        img_size: Image size
        num_batches: Number of batches
        
    Returns:
        DataLoader object
    """
    class SimpleDataset(Dataset):
        def __len__(self):
            return batch_size * num_batches
        
        def __getitem__(self, idx):
            # Create random image
            img = torch.randn(3, img_size, img_size).float()
            
            # Create random annotations
            num_boxes = random.randint(0, 5)
            boxes = torch.zeros(num_boxes, 5)
            for i in range(num_boxes):
                boxes[i] = torch.tensor([
                    random.randint(0, 7),  # class_id
                    random.random(),  # cx
                    random.random(),  # cy
                    random.random() * 0.3,  # w
                    random.random() * 0.3  # h
                ])
            
            return {
                'image': img,
                'boxes': boxes,
                'img_path': f'synthetic_{idx}.jpg',
                'orig_size': torch.tensor([img_size, img_size])
            }
    
    dataset = SimpleDataset()
    
    return DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=True,
        collate_fn=collate_fn,
        num_workers=0
    )


def test_kitti_dataset():
    """Test KITTI dataset"""
    print("🧪 Testing KITTI dataset...")
    print("=" * 60)
    
    try:
        # Test dataset creation
        print("📊 Creating dataset...")
        dataset = KITTIDataset(split="val", img_size=640)
        
        print(f"✅ Dataset created successfully")
        print(f"   Dataset size: {len(dataset)}")
        print(f"   Number of classes: {dataset.config.get('nc', 'unknown')}")
        print(f"   Class list: {dataset.get_classes()}")
        
        # Test data loading
        print("\n📥 Testing data loading...")
        if len(dataset) > 0:
            sample = dataset[0]
            print(f"   Image shape: {sample['image'].shape}")
            print(f"   Number of annotations: {len(sample['boxes'])}")
            print(f"   Image path: {sample['img_path']}")
            
            # Display classes
            if len(sample['boxes']) > 0:
                print(f"   Detected classes: {[dataset.get_class_name(int(box[0])) for box in sample['boxes'].numpy()[:3]]}")
        
        # Test data loader
        print("\n📦 Testing data loader...")
        dataloader, _ = create_kitti_dataloader(
            batch_size=2,
            shuffle=True
        )
        
        # Get one batch
        batch = next(iter(dataloader))
        print(f"   Batch image shape: {batch['image'].shape}")
        print(f"   Batch annotation count: {len(batch['boxes'])}")
        
        # Test visualization
        print("\n👀 Testing visualization...")
        os.makedirs("data/visualization", exist_ok=True)
        dataset.visualize_sample(0, "data/visualization/kitti_sample.png")
        
        print("\n✅ KITTI dataset test completed!")
        return True
        
    except Exception as e:
        print(f"❌ KITTI dataset test failed: {e}")
        import traceback
        traceback.print_exc()
        return False


def get_dataset_statistics(data_dir: str = "data/kitti") -> Dict[str, Any]:
    """
    Get dataset statistics
    
    Parameters:
        data_dir: Data directory
        
    Returns:
        Statistics dictionary
    """
    stats = {
        'dataset': 'KITTI',
        'timestamp': datetime.now().isoformat()
    }
    
    try:
        # Training set statistics
        train_dataset = KITTIDataset(data_dir=data_dir, split="train")
        stats['train'] = {
            'num_samples': len(train_dataset),
            'num_classes': train_dataset.config.get('nc', 0),
            'classes': train_dataset.get_classes()
        }
        
        # Validation set statistics
        val_dataset = KITTIDataset(data_dir=data_dir, split="val")
        stats['val'] = {
            'num_samples': len(val_dataset),
            'num_classes': val_dataset.config.get('nc', 0)
        }
        
        # Calculate annotation statistics
        total_boxes = 0
        class_counts = {}
        
        for i in range(min(100, len(train_dataset))):  # Only count first 100 samples
            sample = train_dataset[i]
            boxes = sample['boxes'].numpy()
            total_boxes += len(boxes)
            
            for box in boxes:
                cls_id = int(box[0])
                class_counts[cls_id] = class_counts.get(cls_id, 0) + 1
        
        stats['annotations'] = {
            'total_boxes_sampled': total_boxes,
            'average_boxes_per_image': total_boxes / 100 if total_boxes > 0 else 0,
            'class_distribution': {
                train_dataset.get_class_name(cls_id): count 
                for cls_id, count in class_counts.items()
            }
        }
        
    except Exception as e:
        stats['error'] = str(e)
    
    return stats


if __name__ == "__main__":
    test_kitti_dataset()