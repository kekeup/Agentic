import torch
import numpy as np
from typing import Dict, Any, List, Tuple
from datetime import datetime
import json
from pathlib import Path

class SimpleEvaluator:
    
    def __init__(self):
        self.evaluation_history = []
        
    def evaluate_detections(self, detections: List[Dict], ground_truths: List[Dict]) -> Dict[str, Any]:
        if not detections or not ground_truths:
            return {
                "mAP": 0.0,
                "precision": 0.0,
                "recall": 0.0,
                "detection_count": 0,
                "ground_truth_count": len(ground_truths),
                "method": "simple_evaluation"
            }
        
       
        detection_count = len(detections)
        gt_count = len(ground_truths)
        
   
        true_positives = min(detection_count, gt_count) * 0.5
        
        precision = true_positives / detection_count if detection_count > 0 else 0
        recall = true_positives / gt_count if gt_count > 0 else 0
        

        if precision + recall > 0:
            f1 = 2 * precision * recall / (precision + recall)
            map_score = f1 * 0.8 
        else:
            map_score = 0.0
        
       
        avg_confidence = np.mean([d.get('confidence', 0) for d in detections]) if detections else 0
        map_score = min(0.9, map_score * (0.7 + avg_confidence * 0.3))
        
        result = {
            "mAP": float(map_score),
            "precision": float(precision),
            "recall": float(recall),
            "detection_count": detection_count,
            "ground_truth_count": gt_count,
            "average_confidence": float(avg_confidence),
            "method": "simplified_calculation",
            "timestamp": datetime.now().isoformat()
        }
        
        self.evaluation_history.append(result)
        
        return result