"""
核心功能模块
包含检测器、评估器、训练器等
"""

try:
    from .detector import UnifiedDetector
    from .evaluator import SimpleEvaluator
    from .ewc_trainer import RealEWCTrainer
    from .map_calculator import RealMAPCalculator
    
    __all__ = [
        'UnifiedDetector',
        'SimpleEvaluator',
        'RealEWCTrainer',
        'RealMAPCalculator'
    ]
except ImportError as e:
    print(f"⚠️  核心模块导入失败: {e}")
    __all__ = []