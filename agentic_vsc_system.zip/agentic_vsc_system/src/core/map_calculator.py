import numpy as np
from typing import List, Dict, Any, Tuple
import json
from pathlib import Path
from datetime import datetime

class RealMAPCalculator:
    """真实mAP计算器 - 使用标准评估方法"""
    
    def __init__(self, num_classes: int = 8, iou_threshold: float = 0.5):

        self.num_classes = num_classes
        self.iou_threshold = iou_threshold
        
        # 存储统计信息
        self.ground_truths = {c: [] for c in range(num_classes)}
        self.detections = {c: [] for c in range(num_classes)}
        
        print(f"📊 真实mAP计算器初始化: {num_classes}个类别, IoU阈值={iou_threshold}")
    
    def calculate_iou(self, box1: np.ndarray, box2: np.ndarray) -> float:
        """计算两个边界框的IoU"""
        # box格式: [x1, y1, x2, y2]
        x1 = max(box1[0], box2[0])
        y1 = max(box1[1], box2[1])
        x2 = min(box1[2], box2[2])
        y2 = min(box1[3], box2[3])
        
        intersection = max(0, x2 - x1) * max(0, y2 - y1)
        
        area1 = (box1[2] - box1[0]) * (box1[3] - box1[1])
        area2 = (box2[2] - box2[0]) * (box2[3] - box2[1])
        union = area1 + area2 - intersection
        
        return intersection / union if union > 0 else 0.0
    
    def add_ground_truth(self, class_id: int, bbox: List[float]):
        """添加真实标注"""
        if 0 <= class_id < self.num_classes:
            self.ground_truths[class_id].append({
                "bbox": bbox,  # [x1, y1, x2, y2]
                "matched": False
            })
    
    def add_detection(self, class_id: int, bbox: List[float], confidence: float):
        """添加检测结果"""
        if 0 <= class_id < self.num_classes:
            self.detections[class_id].append({
                "bbox": bbox,
                "confidence": confidence,
                "matched": False
            })
    
    def calculate_ap_for_class(self, class_id: int) -> float:
        """计算单个类别的AP"""
        gt_boxes = self.ground_truths.get(class_id, [])
        det_boxes = self.detections.get(class_id, [])
        
        if not gt_boxes or not det_boxes:
            return 0.0
        
        # 按置信度排序检测结果
        det_boxes_sorted = sorted(det_boxes, key=lambda x: x["confidence"], reverse=True)
        
        tp = np.zeros(len(det_boxes_sorted))
        fp = np.zeros(len(det_boxes_sorted))
        
        # 对每个检测进行匹配
        for i, det in enumerate(det_boxes_sorted):
            best_iou = 0
            best_gt_idx = -1
            
            for j, gt in enumerate(gt_boxes):
                if gt["matched"]:
                    continue
                
                iou = self.calculate_iou(
                    np.array(det["bbox"]),
                    np.array(gt["bbox"])
                )
                
                if iou > best_iou:
                    best_iou = iou
                    best_gt_idx = j
            
            # 判断是否为真正例
            if best_iou >= self.iou_threshold:
                if not gt_boxes[best_gt_idx]["matched"]:
                    tp[i] = 1
                    gt_boxes[best_gt_idx]["matched"] = True
                else:
                    fp[i] = 1
            else:
                fp[i] = 1
        
        # 计算精度和召回率
        tp_cumsum = np.cumsum(tp)
        fp_cumsum = np.cumsum(fp)
        
        recalls = tp_cumsum / max(len(gt_boxes), 1)
        precisions = tp_cumsum / (tp_cumsum + fp_cumsum + 1e-10)
        
        # 计算AP（11点插值法）
        ap = 0
        for t in np.arange(0, 1.1, 0.1):
            mask = recalls >= t
            if mask.any():
                precision_at_recall = precisions[mask].max()
            else:
                precision_at_recall = 0
            ap += precision_at_recall / 11
        
        return float(ap)
    
    def calculate_map(self) -> Dict[str, Any]:
        """计算mAP"""
        ap_values = []
        class_aps = {}
        
        for class_id in range(self.num_classes):
            ap = self.calculate_ap_for_class(class_id)
            ap_values.append(ap)
            class_aps[f"class_{class_id}"] = ap
        
        map_value = np.mean(ap_values) if ap_values else 0.0
        
        return {
            "mAP": float(map_value),
            "class_APs": class_aps,
            "num_gt": sum(len(v) for v in self.ground_truths.values()),
            "num_det": sum(len(v) for v in self.detections.values())
        }
    
    def reset(self):
        """重置计算器"""
        self.ground_truths = {c: [] for c in range(self.num_classes)}
        self.detections = {c: [] for c in range(self.num_classes)}