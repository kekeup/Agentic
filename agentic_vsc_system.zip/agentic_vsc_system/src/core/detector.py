import torch
import os
from pathlib import Path
from typing import Dict, Any, List
import numpy as np
from datetime import datetime

class UnifiedDetector:
    """统一检测器 - 管理COCO和KITTI模型的检测"""

    def __init__(self, coco_model_path="models/yolov8n.pt", device=None):
        """
        初始化检测器
        
        参数:
            coco_model_path: COCO预训练模型路径
            device: 计算设备
        """
        self.coco_model_path = Path(coco_model_path)
        
        # 自动选择设备
        if device is None:
            self.device = 'cuda' if torch.cuda.is_available() else 'cpu'
        else:
            self.device = device
        
        # 加载COCO模型
        self.coco_model = self._load_yolo_model(self.coco_model_path)
        self.kitti_model = None
        
        # 车辆类别ID (COCO数据集)
        self.vehicle_class_ids = [2, 3, 5, 7]  # car, motorcycle, bus, truck

    def _load_yolo_model(self, model_path):
        """加载YOLOv8模型"""
        try:
            from ultralytics import YOLO
            
            if not model_path.exists():
                raise FileNotFoundError(f"模型文件不存在: {model_path}")
            
            # 加载模型
            model = YOLO(str(model_path))
            model.to(self.device)
            
            return model
            
        except ImportError:
            raise ImportError("请安装ultralytics: pip install ultralytics")
        except Exception as e:
            print(f"加载模型失败: {e}")
            return None

    def load_kitti_model(self, kitti_model_path):
        """加载KITTI微调模型"""
        try:
            # 确保路径是字符串
            if isinstance(kitti_model_path, Path):
                kitti_model_path = str(kitti_model_path)
            
            # 使用 os.path.exists 检查文件是否存在
            if not os.path.exists(kitti_model_path):
                # 查找可能的模型文件
                possible_paths = [
                    "models/model_b_kitti_ewc.pt",
                    "models/yolov8n.pt",
                ]
                
                for file_path in possible_paths:
                    if os.path.exists(file_path):
                        print(f"找到模型文件: {file_path}")
                        kitti_model_path = file_path
                        break
                else:
                    print(f"未找到任何模型文件")
                    return False
            
            print(f"加载KITTI模型: {kitti_model_path}")
            # 加载模型
            self.kitti_model = self._load_yolo_model(Path(kitti_model_path))
            
            return self.kitti_model is not None
                
        except Exception as e:
            print(f"KITTI模型加载失败: {e}")
            return False

    def get_model_info(self, model_type="coco") -> Dict[str, Any]:
        """获取模型信息"""
        if model_type == "coco" and self.coco_model:
            return {
                "model_name": "YOLOv8-COCO",
                "model_path": str(self.coco_model_path),
                "device": self.device,
                "status": "loaded",
                "classes": 80
            }
        elif model_type == "kitti" and self.kitti_model:
            return {
                "model_name": "YOLOv8-KITTI",
                "model_path": "models/model_b_kitti_ewc.pt",
                "device": self.device,
                "status": "loaded",
                "classes": 8
            }
        else:
            return {
                "model_name": "Unknown",
                "status": "not_loaded",
                "error": f"模型 {model_type} 未加载"
            }

    def detect_with_coco(self, image_path: str, conf_threshold: float = 0.25) -> Dict[str, Any]:
        """使用COCO模型检测"""
        return self._detect_with_model(self.coco_model, image_path, conf_threshold, "COCO")

    def detect_with_kitti(self, image_path: str, conf_threshold: float = 0.25) -> Dict[str, Any]:
        """使用KITTI模型检测"""
        if not self.kitti_model:
            # 如果KITTI模型未加载，使用COCO模型
            return self.detect_with_coco(image_path, conf_threshold)
        
        return self._detect_with_model(self.kitti_model, image_path, conf_threshold, "KITTI")

    def _detect_with_model(self, model, image_path: str, conf_threshold: float, model_name: str) -> Dict[str, Any]:
        """使用指定模型进行检测"""
        if not os.path.exists(image_path):
            return self._create_error_result(f"图像文件不存在: {image_path}")
        
        try:
            # 执行检测
            results = model(
                source=image_path,
                conf=conf_threshold,
                device=self.device,
                verbose=False
            )
            
            if not results:
                return self._create_empty_result(image_path, model_name)
            
            result = results[0]
            
            # 提取车辆检测
            detections = []
            vehicle_count = 0
            
            if result.boxes is not None:
                boxes = result.boxes
                for i in range(len(boxes)):
                    box = boxes[i]
                    cls_id = int(box.cls.item())
                    conf = box.conf.item()
                    
                    # 只保留车辆类别
                    if cls_id in self.vehicle_class_ids:
                        bbox = box.xyxy[0].cpu().numpy().tolist()
                        
                        # 获取类别名称
                        class_name = self._get_class_name(cls_id)
                        
                        detections.append({
                            "bbox": bbox,
                            "confidence": conf,
                            "class_id": cls_id,
                            "class_name": class_name,
                            "area": (bbox[2] - bbox[0]) * (bbox[3] - bbox[1])
                        })
                        vehicle_count += 1
            
            # 创建结果字典
            return {
                "detections": detections,
                "image_path": image_path,
                "image_size": result.orig_shape if hasattr(result, 'orig_shape') else (640, 640),
                "model": model_name,
                "timestamp": datetime.now().isoformat(),
                "vehicle_count": vehicle_count,
                "average_confidence": np.mean([d["confidence"] for d in detections]) if detections else 0.0,
                "status": "success"
            }
            
        except Exception as e:
            print(f"检测失败 {image_path}: {e}")
            return self._create_error_result(str(e), image_path)

    def _get_class_name(self, class_id: int) -> str:
        """获取类别名称"""
        class_names = {
            0: "person", 1: "bicycle", 2: "car", 3: "motorcycle",
            4: "airplane", 5: "bus", 6: "train", 7: "truck",
            8: "boat", 9: "traffic light"
        }
        return class_names.get(class_id, f"class_{class_id}")

    def _create_empty_result(self, image_path: str, model_name: str) -> Dict[str, Any]:
        """创建空结果"""
        return {
            "detections": [],
            "image_path": image_path,
            "image_size": (0, 0),
            "model": model_name,
            "timestamp": datetime.now().isoformat(),
            "vehicle_count": 0,
            "average_confidence": 0.0,
            "status": "no_detections"
        }

    def _create_error_result(self, error_msg: str, image_path: str = "") -> Dict[str, Any]:
        """创建错误结果"""
        return {
            "detections": [],
            "image_path": image_path,
            "image_size": (0, 0),
            "model": "error",
            "timestamp": datetime.now().isoformat(),
            "vehicle_count": 0,
            "average_confidence": 0.0,
            "status": "error",
            "error": error_msg
        }

    def get_current_model(self) -> str:
        """获取当前使用的模型"""
        if self.kitti_model:
            return "KITTI"
        else:
            return "COCO"