
__version__ = "5.0"
__author__ = "AGENTIC_VSC_System"
__description__ = "Self-evolving Video Semantic Communication with Agentic AI"

# 导出核心模块
__all__ = [
    'agents',
    'communication',
    'core',
    'datasets',
    'interfaces',
    'main',
    'start'
]

