from pydantic import BaseModel, Field
from typing import Dict, Any, List, Optional
from enum import Enum
from datetime import datetime

class MessageType(str, Enum):
    TASK = "task"
    PROMPT = "prompt"
    JSON_CMD = "json_command"  # JSON命令
    TOOL_CALL = "tool_call"
    TOOL_RESULT = "tool_result"
    REPORT = "report"
    DATA = "data"  # 数据传输
    ALERT = "alert"
    QUERY = "query"  # 新增：自然语言查询

class BaseMessage(BaseModel):
    msg_id: str = Field(default_factory=lambda: f"msg_{datetime.now().timestamp()}")
    msg_type: MessageType
    sender: str
    receiver: str
    timestamp: datetime = Field(default_factory=datetime.now)
    payload: Dict[str, Any] = {}

class TaskMessage(BaseMessage):
    msg_type: MessageType = MessageType.TASK
    payload: Dict[str, Any] = Field(default_factory=lambda: {
        "task_description": "",
        "model": "Model_A",
        "thresholds": {
            "snr_fluctuation": 3.0,
            "map_threshold": 0.35
        },
        "dataset": "kitti"
    })

class JsonCommandMessage(BaseMessage):
    msg_type: MessageType = MessageType.JSON_CMD
    payload: Dict[str, Any] = Field(default_factory=lambda: {
        "action": "data_retrieval",
        "command_id": "",
        "agent_type": "",
        "data_source": "",
        "timestamp": "",
        "parameters": {},
        "status": ""
    })

# 添加 DataMessage 类
class DataMessage(BaseMessage):
    msg_type: MessageType = MessageType.DATA
    payload: Dict[str, Any] = Field(default_factory=lambda: {
        "data_type": "video",
        "data": {},
        "source": "",
        "command_id": "",
        "timestamp": ""
    })

class ReportMessage(BaseMessage):
    msg_type: MessageType = MessageType.REPORT
    payload: Dict[str, Any] = Field(default_factory=lambda: {
        "reason": "",
        "metrics": {},
        "recommendations": []
    })

#新加查询消息
class QueryMessage(BaseMessage):
    msg_type: MessageType = MessageType.QUERY
    payload: Dict[str, Any] = Field(default_factory=lambda: {
        "query": "",
        "context": {},
        "timestamp": ""
    })