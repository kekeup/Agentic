import asyncio
from typing import Dict
from .protocols import BaseMessage, MessageType

class MessageBus:
    def __init__(self):
        self.queues: Dict[str, asyncio.Queue] = {}
        self.subscribers: Dict[MessageType, set] = {msg_type: set() for msg_type in MessageType}
        
    def register_agent(self, agent_id: str):
        self.queues[agent_id] = asyncio.Queue()
        
    async def publish(self, message: BaseMessage):
        if message.receiver in self.queues:
            await self.queues[message.receiver].put(message)
            
    async def receive(self, agent_id: str, timeout: float = 1.0):
        try:
            return await asyncio.wait_for(
                self.queues[agent_id].get(), 
                timeout=timeout
            )
        except asyncio.TimeoutError:
            return None