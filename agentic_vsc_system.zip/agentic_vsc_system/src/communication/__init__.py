# communication/__init__.py
from .message_bus import MessageBus

__all__ = ['MessageBus']